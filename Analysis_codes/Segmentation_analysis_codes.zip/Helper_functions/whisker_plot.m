function whisker_plot(data_mat, data_labels, plot_individual_datapoints, plot_lines_between_points)
% whisker_plot(data_mat, labels, plot_individual_datapoints, plot_lines_between_points)
%
% Creates a whisker plot (min, max, median, quadrants).
% Inputs:
% - a matrix where each column is one data series (group)
% - a cell array of group names (optional)
% - whether to plot individual data points (default - 0)
% - whether to plot lines between corresponding points across bars (within-subject variability) (default - 0)
%
% Based on Alexandra Keinath's function mkWhisker.

if nargin<4
    plot_lines_between_points = 0;
    if nargin<3
        plot_individual_datapoints = 0;
        if nargin<2
            data_labels = [];
        end
    end
end

num_ticks = size(data_mat, 2);
num_datapoints = size(data_mat, 1);
set(gca,'xlim',[0.5 num_ticks+0.5],'xtick',1:num_ticks,'xticklabel',data_labels,'fontname','arial',...
    'fontsize',10,'fontweight','bold')
hold on

if plot_individual_datapoints == 1
%     box_width = 0.3;
    box_width = 0.35;
else
    box_width = 0.5;
end

% groupColor = [200 0 200; 200 0 0; 0 200 0; 0 0 200; 200 200 0] / 255;
% groupColor = [102 204 238; 34 136 51; 204 187 68; 238 102 119] / 255;
% groupColor = [0 112 192; 146 208 80; 192 0 0; 112 48 160] / 255;
groupColor = [68 119 170; 102 204 238; 34 136 51; 204 187 68; 238 102 119; 170 51 119] / 255;
% groupColor = [86 180 233; 213 94 0] / 255;
% groupColor = [127 127 127; 127 127 127; 127 127 127; 127 127 127] / 255;
% groupColor = [200 0 200; 200 0 0; 0 200 0; 0 0 200] / 255;
% groupColor = [0.5 0.7 1; 0.7 0.95 1; 1 0.5 0.75; 1 0.8 0.95; 0.5 0.7 1; 0.7 0.95 1; 1 0.5 0.75; 1 0.8 0.95];

% groupColor = [204 187 68; 68 119 170; 102 204 238; 34 136 51; 238 102 119; 170 51 119] / 255;
% groupColor = [213 94 0; 86 180 233; 0 158 115; 0 114 178; 240 228 66; 230 159 0] / 255;
% groupColor = [213 94 0; 0 114 178; 43 147 205; 86 180 233; 240 228 66; 230 159 0] / 255;
% groupColor = [0 0 200; 0 200 0; 200 0 0; 200 0 200] / 255;

if length(groupColor) < num_ticks
    disp('Not enough colors to plot all data!');
else
    for j = 1:num_ticks
        current_values = sort(data_mat(:,j));
        current_values(isnan(current_values)) = [];
        
        % Plotting the minimum and maximum (line)
        plot([j,j],[max(current_values) min(current_values)],'color','k','linewidth',1.5,'linestyle','-');
        
        % plotting a box from the first to the third quartiles
        patch([(j-(box_width./2)), (j+(box_width./2)), (j+(box_width./2)), (j-(box_width./2))],...
            [current_values(floor(length(current_values).*0.25)) current_values(floor(length(current_values).*0.25)) ...
            current_values(ceil(length(current_values).*0.75)) current_values(ceil(length(current_values).*0.75))],...
            groupColor(ceil(j),:),'edgecolor',groupColor(ceil(j),:),'linewidth',2);
        
        % Plotting a iine at the median of the data
        plot([(j-(box_width./2)), (j+(box_width./2))],...
            [nanmedian(current_values) nanmedian(current_values)],'color','k','linewidth',2);
    end
    
    if plot_individual_datapoints
        hold on;
        for j=1:num_ticks
            %             scatter(ones(num_datapoints,1)*j + rand(num_datapoints,1)*0.12-0.06, data_mat(:,j), 20, [0.2,0.2,0.2]);
            %             scatter(ones(num_datapoints,1)*j + rand(num_datapoints,1)*0.12-0.06, data_mat(:,j), 25, [0.3,0.3,0.3]);
            %             scatter(ones(num_datapoints,1)*j + rand(num_datapoints,1)*0.12-0.06, data_mat(:,j), 20, [0.8,0.8,0.8]);
%             scatter(ones(num_datapoints,1)*j + rand(num_datapoints,1)*0.16-0.08 + 0.3, data_mat(:,j), 10, [0.3,0.3,0.3],'filled');
            scatter(ones(num_datapoints,1)*j + rand(num_datapoints,1)*0.16-0.08 + 0.3, data_mat(:,j), 20, [0.3,0.3,0.3],'filled');
        end
        if plot_lines_between_points
            for j=2:num_ticks
                for i = 1:num_datapoints
                    plot(j-1:j, data_mat(i,j-1:j), 'color', [0.8,0.8,0.8]);
                end
            end
        end
    end
    
end
