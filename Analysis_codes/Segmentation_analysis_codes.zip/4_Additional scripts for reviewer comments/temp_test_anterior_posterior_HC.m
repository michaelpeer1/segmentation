% Defining general variables
betas_file1 = '/Users/mpeer/Dropbox (Epstein Lab)/Epstein Lab Team Folder/Michael_Peer/1 - Segmentation/Segmentation_data/sub-seg01/Analysis/Analysis_objectviewing/Run1/beta_0001.nii';       % Reading one betas file for reslicing of all images to this file's resolution
data_parent_dir = '/Users/mpeer/Dropbox (Epstein Lab)/Epstein Lab Team Folder/Michael_Peer/1 - Segmentation/Segmentation_data';
subj_data_dirs = dir(fullfile(data_parent_dir, 'sub-seg*'));
num_conditions = 16;

all_ROI_names = {'lHC', 'rHC'};
num_ROIs = length(all_ROI_names);


%% Creating the different similarity matrices
% Define locations of objects and create the distance matrix
% (in the paper's figures, the same locations that are here 1-16 are 5,6,...,15,16,1,2,3,4)
locations_all_objects = [16 42; 50 58; 57 27; 25 17; ...
    42 -16; 58 -50; 27 -57; 17 -25; ...
    -16 -42; -50 -58; -57 -27; -25 -17; ...
    -42 16; -58 50; -27 57; -17 25];
mat_distances = pdist2(locations_all_objects, locations_all_objects);         % Distances between all objects
mat_distances = mat_distances / max(mat_distances(:));    % Normalizing to range 0-1
% Create the segment identity similarity matrix
mat_segments = ones(num_conditions);
mat_segments(1:4,1:4) = 0; mat_segments(13:16,13:16) = 0; mat_segments(5:12,5:12) = 0; mat_segments(13:16,1:4) = 0; mat_segments(1:4,13:16) = 0;
% Create the quadrant identity similarity matrix
mat_quadrants = ones(num_conditions);
mat_quadrants(1:4,1:4) = 0; mat_quadrants(5:8,5:8) = 0; mat_quadrants(9:12,9:12) = 0; mat_quadrants(13:16,13:16) = 0;
% Create the orthogonal segment identity similarity matrix
mat_orth_segments = ones(num_conditions);
mat_orth_segments(1:8,1:8) = 0; mat_orth_segments(9:16,9:16) = 0;
% Converting all matrices from dissimilarity to similarity matrices
mat_distances = 1 - mat_distances; mat_segments = 1 - mat_segments; mat_quadrants = 1 - mat_quadrants; mat_orth_segments = 1 - mat_orth_segments;

% Locations of diagonal quadrants
mat_diagonal_quadrants = zeros(num_conditions); mat_diagonal_quadrants(1:4,9:12) = 1; mat_diagonal_quadrants(9:12, 1:4) = 1; mat_diagonal_quadrants(5:8,13:16) = 1; mat_diagonal_quadrants(13:16,5:8) = 1;

% Schema preserving (termed "ROTATION" in the paper) - with distance
locations_new_schema = locations_all_objects;
for i = 1:4
    locations_new_schema(i, :) = locations_new_schema(i + num_conditions/2, :);
end
for i = 13:16
    locations_new_schema(i, :) = locations_new_schema(i - num_conditions/2, :);
end
mat_schema = pdist2(locations_new_schema, locations_new_schema);         % Distances between all objects
mat_schema = mat_schema / max(mat_schema(:));    % Normalizing to range 0-1
mat_schema = 1 - mat_schema;
% Schema preserving - with distance between items in different segments only
mat_schema_between_segments = mat_schema;
mat_schema_between_segments(mat_segments==1) = nan;
% Flipping - between segments adjacent quadrants only
mat_schema_between_segments_adj_quadrants = mat_schema;
mat_schema_between_segments_adj_quadrants(mat_segments==1) = nan;
mat_schema_between_segments_adj_quadrants(mat_diagonal_quadrants==1) = nan;
% Schema preserving - y axis only model
mat_schema_y_axis_only = pdist2(locations_new_schema(:,1), locations_new_schema(:,1));
mat_schema_y_axis_only = mat_schema_y_axis_only / max(mat_schema_y_axis_only(:));    % Normalizing to range 0-1
mat_schema_y_axis_only = 1 - mat_schema_y_axis_only;



% Flipping (termed "MIRRORING" in the paper) - with distance
locations_new_flipping = locations_all_objects;
locations_new_flipping(:,2) = abs(locations_new_flipping(:,2));
mat_flipping = pdist2(locations_new_flipping, locations_new_flipping);         % Distances between all objects
mat_flipping = mat_flipping / max(mat_flipping(:));    % Normalizing to range 0-1
mat_flipping = 1 - mat_flipping;
% Flipping - with distance between items in different segments only
mat_flipping_between_segments = mat_flipping;
mat_flipping_between_segments(mat_segments==1) = nan;
% Flipping - between segments adjacent quadrants only
mat_flipping_between_segments_adj_quadrants = mat_flipping;
mat_flipping_between_segments_adj_quadrants(mat_segments==1) = nan;
mat_flipping_between_segments_adj_quadrants(mat_diagonal_quadrants==1) = nan;
% Flipping - x axis only model
mat_flipping_x_axis_only = pdist2(locations_new_flipping(:,2), locations_new_flipping(:,2));
mat_flipping_x_axis_only = mat_flipping_x_axis_only / max(mat_flipping_x_axis_only(:));    % Normalizing to range 0-1
mat_flipping_x_axis_only = 1 - mat_flipping_x_axis_only;
% Creating the opposite matrix - flipping orthogonal to the river
locations_new_flipping_orthogonal = locations_all_objects;
locations_new_flipping_orthogonal(:,1) = abs(locations_new_flipping_orthogonal(:,1));
mat_orth_flipping = pdist2(locations_new_flipping_orthogonal, locations_new_flipping_orthogonal);         % Distances between all objects
mat_orth_flipping = mat_orth_flipping / max(mat_orth_flipping(:));    % Normalizing to range 0-1
mat_orth_flipping = 1 - mat_orth_flipping;

% Overlay - with distance
locations_new_overlay = locations_all_objects;
locations_new_overlay(5:12,2) = locations_new_overlay(5:12,2) + 75;
mat_overlay = pdist2(locations_new_overlay, locations_new_overlay);         % Distances between all objects
mat_overlay = mat_overlay / max(mat_overlay(:));    % Normalizing to range 0-1
mat_overlay = 1 - mat_overlay;
% Overlay - with distance between items in different segments only
mat_overlay_between_segments = mat_overlay;
mat_overlay_between_segments(mat_segments==1) = nan;
% Overlay - between segments adjacent quadrants only
mat_overlay_between_segments_adj_quadrants = mat_overlay;
mat_overlay_between_segments_adj_quadrants(mat_segments==1) = nan;
mat_overlay_between_segments_adj_quadrants(mat_diagonal_quadrants==1) = nan;
% Overlay - x axis only model
mat_overlay_x_axis_only = pdist2(locations_new_overlay(:,2), locations_new_overlay(:,2));
mat_overlay_x_axis_only = mat_overlay_x_axis_only / max(mat_overlay_x_axis_only(:));    % Normalizing to range 0-1
mat_overlay_x_axis_only = 1 - mat_overlay_x_axis_only;
% Creating the opposite matrix - overlay orthogonal to the river
locations_new_overlay_orthogonal = locations_all_objects;
locations_new_overlay_orthogonal(9:16,1) = locations_new_overlay_orthogonal(9:16,1) + 75;
mat_orth_overlay = pdist2(locations_new_overlay_orthogonal, locations_new_overlay_orthogonal);         % Distances between all objects
mat_orth_overlay = mat_orth_overlay / max(mat_orth_overlay(:));    % Normalizing to range 0-1
mat_orth_overlay = 1 - mat_orth_overlay;

% Organization on X axis (between segments direction)
mat_x_axis = pdist2(locations_all_objects(:,2), locations_all_objects(:,2));
mat_x_axis = mat_x_axis / max(mat_x_axis(:));    % Normalizing to range 0-1
mat_x_axis = 1 - mat_x_axis;
% Organization on Y axis (along river direction)
mat_y_axis = pdist2(locations_all_objects(:,1), locations_all_objects(:,1));
mat_y_axis = mat_y_axis / max(mat_y_axis(:));    % Normalizing to range 0-1
mat_y_axis = 1 - mat_y_axis;
% Organization on X and Y axis within segment and within orthogonal segment only
mat_x_axis_within_segment = mat_x_axis;
mat_x_axis_within_segment(mat_segments==0) = nan;
mat_x_axis_between_segments = mat_x_axis;
mat_x_axis_between_segments(mat_segments==1) = nan;
mat_y_axis_within_segment = mat_y_axis;
mat_y_axis_within_segment(mat_segments==0) = nan;
mat_y_axis_between_segments = mat_y_axis;
mat_y_axis_between_segments(mat_segments==1) = nan;

% Distance within segment only
mat_dist_within_segment = mat_distances;
mat_dist_within_segment(mat_segments==0) = nan;
% Distance between segments only
mat_dist_between_segments = mat_distances;
mat_dist_between_segments(mat_segments==1) = nan;
% Distance within segment, adjacent quadrants only
mat_dist_within_segment_adj_quadrants = mat_distances;
mat_dist_within_segment_adj_quadrants(mat_segments==0) = nan;
mat_dist_within_segment_adj_quadrants(mat_quadrants==1) = nan;
% Distance between segments, adjacent quadrants only
mat_dist_between_segments_adj_quadrants = mat_distances;
mat_dist_between_segments_adj_quadrants(mat_segments==1) = nan;
mat_dist_between_segments_adj_quadrants(mat_diagonal_quadrants==1) = nan;
% Distance between objects in diagonal quadrants only
mat_dist_diagonal_quadrants = nan(num_conditions);
mat_dist_diagonal_quadrants(mat_diagonal_quadrants==1) = mat_distances(mat_diagonal_quadrants==1);
% Distances within quadrant only
mat_dist_within_quadrant = mat_distances;
mat_dist_within_quadrant(mat_quadrants==0) = nan;

% Distances between quadrants (generalizing within quadrant)
mat_quadrants_dist = mat_quadrants;
mat_quadrants_dist(1:4,[5:8,13:16]) = 0.5; mat_quadrants_dist([5:8,13:16],1:4) = 0.5;
mat_quadrants_dist(5:8,9:12) = 0.5; mat_quadrants_dist(9:12,5:8) = 0.5;
mat_quadrants_dist(9:12,13:16) = 0.5; mat_quadrants_dist(13:16,9:12) = 0.5;

% Distance from river
distances_from_river = abs(locations_all_objects(:,2));
mat_distance_from_river = pdist2(distances_from_river, distances_from_river);
mat_distance_from_river = mat_distance_from_river / max(mat_distance_from_river(:));    % Normalizing to range 0-1
mat_distance_from_river = 1 - mat_distance_from_river;

% A matrix coding if it is an adjacent quadrant within and between segment
mat_within_seg_adj_quad = zeros(num_conditions);
mat_within_seg_adj_quad(1:4,13:16) = 1; mat_within_seg_adj_quad(5:8,9:12) = 1; mat_within_seg_adj_quad(9:12,5:8) = 1; mat_within_seg_adj_quad(13:16,1:4) = 1;
mat_between_seg_adj_quad = zeros(num_conditions);
mat_between_seg_adj_quad(1:4,5:8) = 1; mat_between_seg_adj_quad(5:8,1:4) = 1; mat_between_seg_adj_quad(9:12,13:16) = 1; mat_between_seg_adj_quad(13:16,9:12) = 1;

% A matrix coding a segment grouping index - pattern similarity within segment larger than between segments (adjacent quadrants only)
mat_segment_grouping = nan(num_conditions);
mat_segment_grouping(mat_within_seg_adj_quad == 1) = 1;
mat_segment_grouping(mat_between_seg_adj_quad == 1) = -1;
% % A matrix coding a segment grouping index - all regions - by calculating the expected difference under a Euclidean assumption
% grouping_newmeasure_factor = nanmean(mat_distances(mat_segments==1 & eye(num_conditions)~=1)) / nanmean(mat_distances(mat_segments==0 & eye(num_conditions)~=1));
% mat_segment_grouping_newmeasure = nan(num_conditions);
% mat_segment_grouping_newmeasure(mat_segments == 1) = 1;
% mat_segment_grouping_newmeasure(mat_segments == 0) = -1 * grouping_newmeasure_factor;

% Lower triangle elements only
mat_nondiag_distance = mat_distances(find(tril(ones(num_conditions),-1)));
mat_nondiag_segments = mat_segments(find(tril(ones(num_conditions),-1)));
mat_nondiag_orthsegments = mat_orth_segments(find(tril(ones(num_conditions),-1)));
mat_nondiag_quadrants = mat_quadrants(find(tril(ones(num_conditions),-1)));
mat_nondiag_schema = mat_schema(find(tril(ones(num_conditions),-1)));
mat_nondiag_schema_btwn_segments = mat_schema_between_segments(find(tril(ones(num_conditions),-1)));
mat_nondiag_schema_between_seg_adj_quad = mat_schema_between_segments_adj_quadrants(find(tril(ones(num_conditions),-1)));
mat_nondiag_schema_yaxis_only = mat_schema_y_axis_only(find(tril(ones(num_conditions),-1)));
mat_nondiag_flipping = mat_flipping(find(tril(ones(num_conditions),-1)));
mat_nondiag_flipping_btwn_segments = mat_flipping_between_segments(find(tril(ones(num_conditions),-1)));
mat_nondiag_flipping_between_seg_adj_quad = mat_flipping_between_segments_adj_quadrants(find(tril(ones(num_conditions),-1)));
mat_nondiag_flipping_xaxis_only = mat_flipping_x_axis_only(find(tril(ones(num_conditions),-1)));
mat_nondiag_orth_flipping = mat_orth_flipping(find(tril(ones(num_conditions),-1)));
mat_nondiag_overlay = mat_overlay(find(tril(ones(num_conditions),-1)));
mat_nondiag_overlay_btwn_segments = mat_overlay_between_segments(find(tril(ones(num_conditions),-1)));
mat_nondiag_overlay_between_seg_adj_quad = mat_overlay_between_segments_adj_quadrants(find(tril(ones(num_conditions),-1)));
mat_nondiag_overlay_xaxis_only = mat_overlay_x_axis_only(find(tril(ones(num_conditions),-1)));
mat_nondiag_orth_overlay = mat_orth_overlay(find(tril(ones(num_conditions),-1)));
mat_nondiag_y_axis = mat_y_axis(find(tril(ones(num_conditions),-1)));
mat_nondiag_y_axis_between = mat_y_axis_between_segments(find(tril(ones(num_conditions),-1)));
mat_nondiag_y_axis_within = mat_y_axis_within_segment(find(tril(ones(num_conditions),-1)));
mat_nondiag_x_axis = mat_x_axis(find(tril(ones(num_conditions),-1)));
mat_nondiag_x_axis_between = mat_x_axis_between_segments(find(tril(ones(num_conditions),-1)));
mat_nondiag_x_axis_within = mat_x_axis_within_segment(find(tril(ones(num_conditions),-1)));
mat_nondiag_dist_within_segment = mat_dist_within_segment(find(tril(ones(num_conditions),-1)));
mat_nondiag_dist_between_segments = mat_dist_between_segments(find(tril(ones(num_conditions),-1)));
mat_nondiag_dist_within_segment_adj_quadrants = mat_dist_within_segment_adj_quadrants(find(tril(ones(num_conditions),-1)));
mat_nondiag_dist_between_segments_adj_quadrants = mat_dist_between_segments_adj_quadrants(find(tril(ones(num_conditions),-1)));
mat_nondiag_dist_diagonal_quadrants = mat_dist_diagonal_quadrants(find(tril(ones(num_conditions),-1)));
mat_nondiag_dist_within_quadrant = mat_dist_within_quadrant(find(tril(ones(num_conditions),-1)));
mat_nondiag_dist_diagonal_quadrants = mat_dist_diagonal_quadrants(find(tril(ones(num_conditions),-1)));
mat_nondiag_distance_from_river = mat_distance_from_river(find(tril(ones(num_conditions),-1)));
mat_nondiag_quadrants_dist = mat_quadrants_dist(find(tril(ones(num_conditions),-1)));
mat_nondiag_within_seg_adj_quad = mat_within_seg_adj_quad(find(tril(ones(num_conditions),-1)));
mat_nondiag_between_seg_adj_quad = mat_between_seg_adj_quad(find(tril(ones(num_conditions),-1)));
mat_nondiag_segment_grouping = mat_segment_grouping(find(tril(ones(num_conditions),-1)));
% mat_nondiag_segment_grouping_newmeasure = mat_segment_grouping_newmeasure(find(tril(ones(num_conditions),-1)));

% Creating a template that balances the diagonal minus nondiagonal elements, to calculate their weighted subraction
diag_nondiag_template = (eye(num_conditions) - 1 / num_conditions) / (num_conditions - 1);



%% RSA in ROIs

% Initialize variables
means_diag_minus_nondiag_objview_halfruns = nan(length(subj_data_dirs), num_ROIs);

corr_objview_d2minusd1_distances = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_segments = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_orth_segments = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_quadrants = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_schema = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_schema_btwn = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_schema_btwn_seg_adj_quad = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_schema_yaxis_only = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_flipping = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_flipping_btwn = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_flipping_btwn_seg_adj_quad = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_flipping_xaxis_only = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_orth_flipping = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_overlay = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_overlay_btwn = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_overlay_btwn_seg_adj_quad = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_overlay_xaxis_only = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_orth_overlay = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_distance_from_river = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_x_axis = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_y_axis = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_dist_within_segment = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_dist_between_segments = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_dist_within_quadrant = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_dist_within_segment_adj_quad = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_dist_between_segments_adj_quad = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_dist_diagonal_quadrants = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_quadrants_dist = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_estimated_dist = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_x_axis_within_segment = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_y_axis_within_segment = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_x_axis_between_segments = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_y_axis_between_segments = nan(length(subj_data_dirs), num_ROIs);

corr_objview_day2_distances = nan(length(subj_data_dirs), num_ROIs);
corr_objview_day2_segments = nan(length(subj_data_dirs), num_ROIs);
corr_objview_day2_orth_segments = nan(length(subj_data_dirs), num_ROIs);
corr_objview_day2_quadrants = nan(length(subj_data_dirs), num_ROIs);
corr_objview_day2_coviewing = nan(length(subj_data_dirs), num_ROIs);
corr_objview_day2_schema = nan(length(subj_data_dirs), num_ROIs);
corr_objview_day2_schema_btwn = nan(length(subj_data_dirs), num_ROIs);
corr_objview_day2_schema_btwn_seg_adj_quad = nan(length(subj_data_dirs), num_ROIs);
corr_objview_day2_schema_y_axis_only = nan(length(subj_data_dirs), num_ROIs);
corr_objview_day2_flipping = nan(length(subj_data_dirs), num_ROIs);
corr_objview_day2_flipping_btwn = nan(length(subj_data_dirs), num_ROIs);
corr_objview_day2_flipping_btwn_seg_adj_quad = nan(length(subj_data_dirs), num_ROIs);
corr_objview_day2_flipping_x_axis_only = nan(length(subj_data_dirs), num_ROIs);
corr_objview_day2_orth_flipping = nan(length(subj_data_dirs), num_ROIs);
corr_objview_day2_overlay = nan(length(subj_data_dirs), num_ROIs);
corr_objview_day2_overlay_btwn = nan(length(subj_data_dirs), num_ROIs);
corr_objview_day2_overlay_btwn_seg_adj_quad = nan(length(subj_data_dirs), num_ROIs);
corr_objview_day2_overlay_x_axis_only = nan(length(subj_data_dirs), num_ROIs);
corr_objview_day2_orth_overlay = nan(length(subj_data_dirs), num_ROIs);
corr_objview_day2_distance_from_river = nan(length(subj_data_dirs), num_ROIs);
corr_objview_day2_x_axis = nan(length(subj_data_dirs), num_ROIs);
corr_objview_day2_y_axis = nan(length(subj_data_dirs), num_ROIs);
corr_objview_day2_dist_within_segment = nan(length(subj_data_dirs), num_ROIs);
corr_objview_day2_dist_between_segments = nan(length(subj_data_dirs), num_ROIs);
corr_objview_day2_dist_within_quadrant = nan(length(subj_data_dirs), num_ROIs);
corr_objview_day2_dist_within_segment_adj_quad = nan(length(subj_data_dirs), num_ROIs);
corr_objview_day2_dist_between_segments_adj_quad = nan(length(subj_data_dirs), num_ROIs);
corr_objview_day2_dist_diagonal_quadrants = nan(length(subj_data_dirs), num_ROIs);
corr_objview_day2_quadrants_dist = nan(length(subj_data_dirs), num_ROIs);
corr_objview_day2_estimated_dist = nan(length(subj_data_dirs), num_ROIs);
corr_objview_day2_x_axis_within_segment = nan(length(subj_data_dirs), num_ROIs);
corr_objview_day2_y_axis_within_segment = nan(length(subj_data_dirs), num_ROIs);
corr_objview_day2_x_axis_between_segments = nan(length(subj_data_dirs), num_ROIs);
corr_objview_day2_y_axis_between_segments = nan(length(subj_data_dirs), num_ROIs);

corr_jrd_distances = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_segments = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_orth_segments = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_quadrants = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_schema = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_schema_btwn = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_schema_btwn_seg_adj_quad = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_schema_y_axis_only = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_flipping = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_flipping_btwn = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_flipping_btwn_seg_adj_quad = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_flipping_x_axis_only = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_orth_flipping = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_overlay = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_overlay_btwn = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_overlay_btwn_seg_adj_quad = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_overlay_x_axis_only = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_orth_overlay = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_distance_from_river = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_x_axis = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_y_axis = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_dist_within_segment = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_dist_between_segments = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_dist_within_quadrant = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_dist_within_segment_adj_quad = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_dist_between_segments_adj_quad = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_dist_diagonal_quadrants = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_quadrants_dist = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_estimated_dist = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_x_axis_within_segment = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_y_axis_within_segment = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_x_axis_between_segments = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_y_axis_between_segments = nan(length(subj_data_dirs), num_ROIs);

corr_jrd_coviewing = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_resp_similarity = nan(length(subj_data_dirs), num_ROIs);

partialcorr_objview_d2minusd1_distances = nan(length(subj_data_dirs), num_ROIs);
partialcorr_objview_d2minusd1_segments = nan(length(subj_data_dirs), num_ROIs);
partialcorr_objview_d2minusd1_orthsegments = nan(length(subj_data_dirs), num_ROIs);
partialcorr_objview_d2minusd1_quadrants = nan(length(subj_data_dirs), num_ROIs);
partialcorr_jrd_distances = nan(length(subj_data_dirs), num_ROIs);
partialcorr_jrd_distances_cov_resp = nan(length(subj_data_dirs), num_ROIs);
partialcorr_jrd_overlay_cov_resp = nan(length(subj_data_dirs), num_ROIs);
partialcorr_jrd_flipping_cov_resp = nan(length(subj_data_dirs), num_ROIs);
partialcorr_jrd_yaxis_cov_resp = nan(length(subj_data_dirs), num_ROIs);
partialcorr_jrd_segments = nan(length(subj_data_dirs), num_ROIs);
partialcorr_jrd_orthsegments = nan(length(subj_data_dirs), num_ROIs);
partialcorr_jrd_quadrants = nan(length(subj_data_dirs), num_ROIs);

segment_grouping_objview_d2minusd1 = nan(length(subj_data_dirs), num_ROIs);
segment_grouping_newmeasure_objview_d2minusd1 = nan(length(subj_data_dirs), num_ROIs);
segment_remapping_objview_d2minusd1_full = nan(length(subj_data_dirs), num_ROIs);
segment_remapping_objview_d2minusd1_adjquads = nan(length(subj_data_dirs), num_ROIs);
segment_grouping_jrd = nan(length(subj_data_dirs), num_ROIs);
segment_grouping_newmeasure_jrd = nan(length(subj_data_dirs), num_ROIs);
segment_remapping_jrd_full = nan(length(subj_data_dirs), num_ROIs);
segment_remapping_jrd_adjquads = nan(length(subj_data_dirs), num_ROIs);

all_neural_corr_ROI_jrd_nondiag = nan(length(mat_nondiag_distance), num_ROIs, length(subj_data_dirs));
all_neural_corr_objview_day2_nondiag = nan(length(mat_nondiag_distance), num_ROIs, length(subj_data_dirs));
all_neural_corr_objview_d2minusd1_nondiag = nan(length(mat_nondiag_distance), num_ROIs, length(subj_data_dirs));

allsubjs_pattern_dist_objectviewing_day2 = cell(size(all_ROI_names));
allsubjs_pattern_dist_objectviewing_day2minus1 = cell(size(all_ROI_names));
allsubjs_pattern_dist_jrd = cell(size(all_ROI_names));
for i=1:length(all_ROI_names)
    allsubjs_pattern_dist_objectviewing_day2{i} = nan(num_conditions,num_conditions,length(subj_data_dirs));
    allsubjs_pattern_dist_objectviewing_day2minus1{i} = nan(num_conditions,num_conditions,length(subj_data_dirs));
    allsubjs_pattern_dist_jrd{i} = nan(num_conditions,num_conditions,length(subj_data_dirs));
end

all_neural_corr_ROI_jrd = nan(num_conditions, num_conditions, num_ROIs, length(subj_data_dirs));
all_neural_corr_objview_day2 = nan(num_conditions, num_conditions, num_ROIs, length(subj_data_dirs));
all_neural_corr_objview_d2minusd1 = nan(num_conditions, num_conditions, num_ROIs, length(subj_data_dirs));

% sz = size(spm_read_vols(spm_vol(betas_file1)));
% all_post_left = zeros(sz); all_post_right = zeros(sz); all_ant_left = zeros(sz); all_ant_right = zeros(sz); 


% Calculation RSA in each subject and ROI
for subj = 1:length(subj_data_dirs)
    % Defining current subject directories
    disp(subj)
    % Object viewing analysis dirs
    curr_subj_analysis_dir = fullfile(fullfile(data_parent_dir, subj_data_dirs(subj).name), 'Analysis');
    curr_subj_objectviewing_analysis_dir = fullfile(curr_subj_analysis_dir, 'Analysis_objectviewing');
    curr_subj_objectviewing_analysis_dirs = {fullfile(curr_subj_objectviewing_analysis_dir, 'Run1'),...
        fullfile(curr_subj_objectviewing_analysis_dir, 'Run2'),...
        fullfile(curr_subj_objectviewing_analysis_dir, 'Run3'),...
        fullfile(curr_subj_objectviewing_analysis_dir, 'Run4')};
    num_runs_objectviewing = length(curr_subj_objectviewing_analysis_dirs);
    curr_subj_objectviewing_combined_dirs = {fullfile(curr_subj_objectviewing_analysis_dir, 'Combined_runs_day1'),...
        fullfile(curr_subj_objectviewing_analysis_dir, 'Combined_runs_day2')};
    % JRD analysis dirs
    curr_subj_jrd_analysis_dir = fullfile(curr_subj_analysis_dir, 'Analysis_JRD');
    curr_subj_jrd_analysis_dirs = {fullfile(curr_subj_jrd_analysis_dir, 'Run1'),...
        fullfile(curr_subj_jrd_analysis_dir, 'Run2'),...
        fullfile(curr_subj_jrd_analysis_dir, 'Run3')};
    curr_subj_jrd_adaptation_analysis_dir = fullfile(curr_subj_analysis_dir, 'Analysis_JRD_adaptation');
    num_runs_jrd = length(dir(fullfile(curr_subj_jrd_adaptation_analysis_dir, '*confounds.mat')));
    curr_subj_jrd_combined_dir = fullfile(curr_subj_jrd_analysis_dir, 'Combined_runs');
    % Functional localizer analysis dirs
    curr_subj_localizer_analysis_dir = fullfile(curr_subj_analysis_dir, 'Analysis_localizer');
    
    
    %% Loading the subject specific ROIs
    all_ROIs_individual = {};
    for i = 1:num_ROIs
        all_ROIs_individual{i} = spm_read_vols(spm_vol(fullfile(curr_subj_localizer_analysis_dir, [all_ROI_names{i}, '_individual.nii'])));
    end
    % DIVIDING HC INTO POSTERIOR AND ANTERIOR
    post_ROIs = all_ROIs_individual;
    ant_ROIs = all_ROIs_individual;
    % Finding the midpoint of HC for this subject (middle coordinate from most posterior to most anterior coordinate in HC)
    c = all_ROIs_individual{1}+all_ROIs_individual{2};      % Bilateral HC
    midpoint = round((max(find(sum(sum(c,1),3)))-min(find(sum(sum(c,1),3))))/2+min(find(sum(sum(c,1),3)))); % Finding the midpoint of HC
    % Creating posterior and anterior ROIs
    for i = 1:num_ROIs
        post_ROIs{i}(:,midpoint:end,:) = 0;
        ant_ROIs{i}(:,1:midpoint,:) = 0;
        % Saving the ROIs
        save_mat_to_nifti(fullfile(curr_subj_localizer_analysis_dir, [all_ROI_names{i}, '_individual.nii']), post_ROIs{i}, fullfile(curr_subj_localizer_analysis_dir, [all_ROI_names{i}, 'post_individual.nii']));
        save_mat_to_nifti(fullfile(curr_subj_localizer_analysis_dir, [all_ROI_names{i}, '_individual.nii']), ant_ROIs{i}, fullfile(curr_subj_localizer_analysis_dir, [all_ROI_names{i}, 'ant_individual.nii']));
    end
    all_ROIs_individual = [post_ROIs,ant_ROIs,all_ROIs_individual];    
    
    
    %     all_post_left = all_post_left + post_ROIs{1};
    %     all_post_right = all_post_right + post_ROIs{2};
    %     all_ant_left = all_ant_left + ant_ROIs{1};
    %     all_ant_right = all_ant_right + ant_ROIs{2};
    
    %% Reading the individual subject's estimated distance matrix
    mat_estimated_dist = load(fullfile(curr_subj_jrd_analysis_dir, 'estimated_distances_mat.mat'));
    mat_estimated_dist = mat_estimated_dist.dist_matrix;
    % Converting to a maximum of 1
    mat_estimated_dist = mat_estimated_dist / max(mat_estimated_dist(:));
    % Converting to similarity matrix
    mat_estimated_dist = 1 - mat_estimated_dist;
    mat_nondiag_estimated_dist = mat_estimated_dist(find(tril(ones(num_conditions),-1)));
    
    
    %% MVPA analysis in each ROI
    for roi = 1:length(all_ROIs_individual)        % Going over ROIs
        curr_ROI = find(all_ROIs_individual{roi}(:)==1);
        if ~isempty(curr_ROI)
            % Reading object viewing data in the ROI
            all_tvalues_ROI_objview = nan(length(curr_ROI), num_conditions, length(curr_subj_objectviewing_combined_dirs));
            for r = 1:length(curr_subj_objectviewing_combined_dirs)
                t_values_files_current = dir(fullfile(curr_subj_objectviewing_combined_dirs{r}, 'spmT*.nii'));
                for b = 1:num_conditions
                    curr_tvalues_image = spm_read_vols(spm_vol(fullfile(curr_subj_objectviewing_combined_dirs{r}, t_values_files_current(b).name)));
                    all_tvalues_ROI_objview(:,b,r) = curr_tvalues_image(curr_ROI);
                end
            end
            % Removing the cocktail mean from each day (mean activity at each voxel across patterns)
            for r = 1:length(curr_subj_objectviewing_combined_dirs)
                mean_day_pattern = nanmean(all_tvalues_ROI_objview(:,:,r), 2);
                for b = 1:num_conditions
                    all_tvalues_ROI_objview(:,b,r) = all_tvalues_ROI_objview(:,b,r) - mean_day_pattern;
                end
            end
            
            % Object viewing runs - calculating correlation between day1 patterns and day2 patterns
            curr_corr = fisherz(corr(all_tvalues_ROI_objview(:,:,1), all_tvalues_ROI_objview(:,:,2), 'rows', 'complete'));                 % Correlation between first and second halves of runs
            means_diag_minus_nondiag_objview_halfruns(subj, roi) = sum(sum(diag_nondiag_template .* curr_corr));                          % Diagonal minus nondiagonal elements
            
            % Object viewing runs - calculating correlation to distance and segment matrices
            corr_ROI_objview_day1 = fisherz(corr(all_tvalues_ROI_objview(:,:,1), all_tvalues_ROI_objview(:,:,1), 'rows', 'complete'));                    % Correlation between day 1 patterns, averaged across runs
            corr_ROI_objview_day2 = fisherz(corr(all_tvalues_ROI_objview(:,:,2), all_tvalues_ROI_objview(:,:,2),'rows', 'complete'));                    % Correlation between day 2 patterns, averaged across runs
            % Non-diagonal elements
            corr_ROI_objview_day1_nondiag = corr_ROI_objview_day1(find(tril(ones(num_conditions),-1)));       % Taking only the lower triangle elements as a vector
            corr_ROI_objview_day2_nondiag = corr_ROI_objview_day2(find(tril(ones(num_conditions),-1)));       % Taking only the lower triangle elements as a vector
            corr_ROI_objview_d2minusd1_nondiag = (corr_ROI_objview_day2_nondiag - corr_ROI_objview_day1_nondiag);            % Day2 minus day1
            
            % Calculating correlation to different matrices
            % Day 2
            corr_objview_day2_distances(subj, roi) = corr(corr_ROI_objview_day2_nondiag, mat_nondiag_distance, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_day2_segments(subj, roi) = corr(corr_ROI_objview_day2_nondiag, mat_nondiag_segments, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_day2_quadrants(subj, roi) = corr(corr_ROI_objview_day2_nondiag, mat_nondiag_quadrants, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_day2_orth_segments(subj, roi) = corr(corr_ROI_objview_day2_nondiag, mat_nondiag_orthsegments, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_day2_schema(subj, roi) = corr(corr_ROI_objview_day2_nondiag, mat_nondiag_schema, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_day2_schema_btwn(subj, roi) = corr(corr_ROI_objview_day2_nondiag, mat_nondiag_schema_btwn_segments, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_day2_schema_btwn_seg_adj_quad(subj, roi) = corr(corr_ROI_objview_day2_nondiag, mat_nondiag_schema_between_seg_adj_quad, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_day2_schema_y_axis_only(subj, roi) = corr(corr_ROI_objview_day2_nondiag, mat_nondiag_schema_yaxis_only, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_day2_flipping(subj, roi) = corr(corr_ROI_objview_day2_nondiag, mat_nondiag_flipping, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_day2_flipping_btwn(subj, roi) = corr(corr_ROI_objview_day2_nondiag, mat_nondiag_flipping_btwn_segments, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_day2_flipping_btwn_seg_adj_quad(subj, roi) = corr(corr_ROI_objview_day2_nondiag, mat_nondiag_flipping_between_seg_adj_quad, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_day2_flipping_x_axis_only(subj, roi) = corr(corr_ROI_objview_day2_nondiag, mat_nondiag_flipping_xaxis_only, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_day2_orth_flipping(subj, roi) = corr(corr_ROI_objview_day2_nondiag, mat_nondiag_orth_flipping, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_day2_overlay(subj, roi) = corr(corr_ROI_objview_day2_nondiag, mat_nondiag_overlay, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_day2_overlay_btwn(subj, roi) = corr(corr_ROI_objview_day2_nondiag, mat_nondiag_overlay_btwn_segments, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_day2_overlay_btwn_seg_adj_quad(subj, roi) = corr(corr_ROI_objview_day2_nondiag, mat_nondiag_overlay_between_seg_adj_quad, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_day2_overlay_x_axis_only(subj, roi) = corr(corr_ROI_objview_day2_nondiag, mat_nondiag_overlay_xaxis_only, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_day2_orth_overlay(subj, roi) = corr(corr_ROI_objview_day2_nondiag, mat_nondiag_orth_overlay, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_day2_dist_within_segment(subj, roi) = corr(corr_ROI_objview_day2_nondiag, mat_nondiag_dist_within_segment, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_day2_dist_between_segments(subj, roi) = corr(corr_ROI_objview_day2_nondiag, mat_nondiag_dist_between_segments, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_day2_dist_within_quadrant(subj, roi) = corr(corr_ROI_objview_day2_nondiag, mat_nondiag_dist_within_quadrant, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_day2_dist_within_segment_adj_quad(subj, roi) = corr(corr_ROI_objview_day2_nondiag, mat_nondiag_dist_within_segment_adj_quadrants, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_day2_dist_between_segments_adj_quad(subj, roi) = corr(corr_ROI_objview_day2_nondiag, mat_nondiag_dist_between_segments_adj_quadrants, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_day2_dist_diagonal_quadrants(subj, roi) = corr(corr_ROI_objview_day2_nondiag, mat_nondiag_dist_diagonal_quadrants, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_day2_x_axis(subj, roi) = corr(corr_ROI_objview_day2_nondiag, mat_nondiag_x_axis, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_day2_x_axis_between_segments(subj, roi) = corr(corr_ROI_objview_day2_nondiag, mat_nondiag_x_axis_between, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_day2_x_axis_within_segment(subj, roi) = corr(corr_ROI_objview_day2_nondiag, mat_nondiag_x_axis_within, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_day2_y_axis(subj, roi) = corr(corr_ROI_objview_day2_nondiag, mat_nondiag_y_axis, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_day2_y_axis_between_segments(subj, roi) = corr(corr_ROI_objview_day2_nondiag, mat_nondiag_y_axis_between, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_day2_y_axis_within_segment(subj, roi) = corr(corr_ROI_objview_day2_nondiag, mat_nondiag_y_axis_within, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_day2_distance_from_river(subj, roi) = corr(corr_ROI_objview_day2_nondiag, mat_nondiag_distance_from_river, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_day2_quadrants_dist(subj, roi) = corr(corr_ROI_objview_day2_nondiag, mat_nondiag_quadrants_dist, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_day2_estimated_dist(subj, roi) = corr(corr_ROI_objview_day2_nondiag, mat_nondiag_estimated_dist, 'Type', 'Spearman', 'rows', 'complete');
            
            % Day 2 minus day 1 (change in corrrelation between days)
            corr_objview_d2minusd1_distances(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_distance, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_segments(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_segments, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_quadrants(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_quadrants, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_orth_segments(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_orthsegments, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_schema(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_schema, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_schema_btwn(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_schema_btwn_segments, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_schema_btwn_seg_adj_quad(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_schema_between_seg_adj_quad, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_schema_y_axis_only(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_schema_yaxis_only, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_flipping(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_flipping, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_flipping_btwn(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_flipping_btwn_segments, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_flipping_btwn_seg_adj_quad(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_flipping_between_seg_adj_quad, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_flipping_x_axis_only(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_flipping_xaxis_only, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_orth_flipping(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_orth_flipping, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_overlay(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_overlay, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_overlay_btwn(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_overlay_btwn_segments, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_overlay_btwn_seg_adj_quad(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_overlay_between_seg_adj_quad, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_overlay_x_axis_only(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_overlay_xaxis_only, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_orth_overlay(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_orth_overlay, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_dist_within_segment(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_dist_within_segment, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_dist_between_segments(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_dist_between_segments, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_dist_within_quadrant(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_dist_within_quadrant, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_dist_within_segment_adj_quad(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_dist_within_segment_adj_quadrants, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_dist_between_segments_adj_quad(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_dist_between_segments_adj_quadrants, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_dist_diagonal_quadrants(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_dist_diagonal_quadrants, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_x_axis(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_x_axis, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_x_axis_between_segments(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_x_axis_between, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_x_axis_within_segment(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_x_axis_within, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_y_axis(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_y_axis, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_y_axis_between_segments(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_y_axis_between, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_y_axis_within_segment(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_y_axis_within, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_distance_from_river(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_distance_from_river, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_quadrants_dist(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_quadrants_dist, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_estimated_dist(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_estimated_dist, 'Type', 'Spearman', 'rows', 'complete');
            
            % Object viewing runs - partial correlation - day 2 minus day 1 correlations
            partialcorr_objview_d2minusd1_distances(subj, roi) = partialcorr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_distance, mat_nondiag_segments, 'Type', 'Spearman', 'rows', 'complete');
            partialcorr_objview_d2minusd1_segments(subj, roi) = partialcorr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_segments, mat_nondiag_distance, 'Type', 'Spearman', 'rows', 'complete');
            partialcorr_objview_d2minusd1_orthsegments(subj, roi) = partialcorr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_orthsegments, mat_nondiag_distance, 'Type', 'Spearman', 'rows', 'complete');
            partialcorr_objview_d2minusd1_quadrants(subj, roi) = partialcorr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_quadrants, mat_nondiag_distance, 'Type', 'Spearman', 'rows', 'complete');
            partialcorr_objview_d2minusd1_distances_overlay(subj, roi) = partialcorr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_distance, mat_nondiag_overlay, 'Type', 'Spearman', 'rows', 'complete');
            partialcorr_objview_d2minusd1_overlay_distances(subj, roi) = partialcorr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_overlay, mat_nondiag_distance, 'Type', 'Spearman', 'rows', 'complete');
            
            % Calculating the segment grouping measure (higher neural similarity within segment compared to between)
            segment_grouping_objview_d2minusd1(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_segment_grouping, 'Type', 'Spearman', 'rows', 'complete');
%             segment_grouping_newmeasure_objview_d2minusd1(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_segment_grouping_newmeasure, 'Type', 'Spearman', 'rows', 'complete');
            grouping_newmeasure_factor = nanmean(mat_nondiag_distance(mat_nondiag_segments==1))/nanmean(mat_nondiag_distance(mat_nondiag_segments==0));
            segment_grouping_newmeasure_objview_d2minusd1(subj, roi) = grouping_newmeasure_factor * nanmean(corr_ROI_objview_d2minusd1_nondiag(mat_nondiag_segments==1)) - nanmean(corr_ROI_objview_d2minusd1_nondiag(mat_nondiag_segments==0));
            % Calculating the segment remapping measure (higher correlation to distance matrix within segment vs. between segments)
            segment_remapping_objview_d2minusd1_full(subj, roi) = corr_objview_d2minusd1_dist_within_segment(subj, roi) - corr_objview_d2minusd1_dist_between_segments(subj, roi);
            segment_remapping_objview_d2minusd1_adjquads(subj, roi) = corr_objview_d2minusd1_dist_within_segment_adj_quad(subj, roi) - corr_objview_d2minusd1_dist_between_segments_adj_quad(subj, roi);
            
            % Saving the actual neural correlations
            all_neural_corr_objview_day2_nondiag(:,roi,subj) = corr_ROI_objview_day2_nondiag;
            all_neural_corr_objview_d2minusd1_nondiag(:,roi,subj) = corr_ROI_objview_d2minusd1_nondiag;

            
            % Neural distances
            all_neural_corr_objview_day2(:,:,roi,subj) = corr_ROI_objview_day2;
            all_neural_corr_objview_d2minusd1(:,:,roi,subj) = corr_ROI_objview_day2 - corr_ROI_objview_day1;
            
            % Pattern distances
            pattern_dist_objectviewing_day1 = 1 - corr_ROI_objview_day1;
            pattern_dist_objectviewing_day2 = 1 - corr_ROI_objview_day2;            
            allsubjs_pattern_dist_objectviewing_day2{roi}(:,:,subj) = pattern_dist_objectviewing_day2;
            allsubjs_pattern_dist_objectviewing_day2minus1{roi}(:,:,subj) = pattern_dist_objectviewing_day2 - pattern_dist_objectviewing_day1;

            % JRD
            if num_runs_jrd > 0
                % Extracting the t-values at each ROI - JRD
                all_tvalues_ROI_jrd = nan(length(curr_ROI), num_conditions);
                t_values_files_current = dir(fullfile(curr_subj_jrd_combined_dir, 'spmT*.nii'));
                for b = 1:num_conditions
                    curr_tvalues_image = spm_read_vols(spm_vol(fullfile(curr_subj_jrd_combined_dir, t_values_files_current(b).name)));
                    all_tvalues_ROI_jrd(:,b) = curr_tvalues_image(curr_ROI);
                end
                % Removing the cocktail mean (mean activity at each voxel across patterns)
                mean_jrd_pattern = nanmean(all_tvalues_ROI_jrd, 2);
                for b = 1:num_conditions
                    all_tvalues_ROI_jrd(:,b) = all_tvalues_ROI_jrd(:,b) - mean_jrd_pattern;
                end
                
                % JRD - Calculating correlation to different matrices
                corr_ROI_jrd = fisherz(corr(all_tvalues_ROI_jrd, all_tvalues_ROI_jrd, 'rows', 'complete'));
                if ~isempty(corr_ROI_jrd)
                    % Getting the non-diagonal elements only of the across-run-combinations-average correlation matrix, averaged across upper and lower triangles
                    corr_ROI_jrd_nondiag = corr_ROI_jrd(find(tril(ones(num_conditions),-1)));
                    
                    % Reading this subject's co-viewing stats and responses similarity stats (created with the behavioral analysis script - analyze_psychopy_all_subjects.m)
                    curr_coviewing_mat_file = fullfile(curr_subj_jrd_analysis_dir, 'object_coviewing_JRD.mat');
                    if exist(curr_coviewing_mat_file, 'file')
                        coviewing_mat = load(fullfile(curr_subj_jrd_analysis_dir, 'object_coviewing_JRD.mat'));
                        coviewing_mat = coviewing_mat.current_subject_coviewing_mat;
                    end
                    curr_resp_similarity_mat_file = fullfile(curr_subj_jrd_analysis_dir, 'responses_similarity_JRD.mat');
                    if exist(curr_resp_similarity_mat_file, 'file')
                        resp_similarity_mat = load(fullfile(curr_subj_jrd_analysis_dir, 'responses_similarity_JRD.mat'));
                        resp_similarity_mat = 1 - resp_similarity_mat.current_responses_diff;       % Converting to similarity instead of dissimilarity
                    end
                    mat_nondiag_coviewing = coviewing_mat(find(tril(ones(num_conditions),-1)));
                    mat_nondiag_resp_similarity = resp_similarity_mat(find(tril(ones(num_conditions),-1)));
                    
                    % Correlations to different matrices
                    corr_jrd_distances(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_distance, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_segments(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_segments, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_quadrants(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_quadrants, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_orth_segments(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_orthsegments, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_schema(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_schema, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_schema_btwn(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_schema_btwn_segments, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_schema_btwn_seg_adj_quad(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_schema_between_seg_adj_quad, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_schema_y_axis_only(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_schema_yaxis_only, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_flipping(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_flipping, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_flipping_btwn(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_flipping_btwn_segments, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_flipping_btwn_seg_adj_quad(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_flipping_between_seg_adj_quad, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_flipping_x_axis_only(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_flipping_xaxis_only, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_orth_flipping(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_orth_flipping, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_overlay(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_overlay, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_overlay_btwn(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_overlay_btwn_segments, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_overlay_btwn_seg_adj_quad(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_overlay_between_seg_adj_quad, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_overlay_x_axis_only(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_overlay_xaxis_only, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_orth_overlay(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_orth_overlay, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_dist_within_segment(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_dist_within_segment, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_dist_between_segments(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_dist_between_segments, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_dist_within_quadrant(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_dist_within_quadrant, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_dist_within_segment_adj_quad(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_dist_within_segment_adj_quadrants, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_dist_between_segments_adj_quad(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_dist_between_segments_adj_quadrants, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_dist_diagonal_quadrants(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_dist_diagonal_quadrants, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_x_axis(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_x_axis, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_x_axis_between_segments(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_x_axis_between, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_x_axis_within_segment(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_x_axis_within, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_y_axis(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_y_axis, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_y_axis_between_segments(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_y_axis_between, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_y_axis_within_segment(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_y_axis_within, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_distance_from_river(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_distance_from_river, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_quadrants_dist(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_quadrants_dist, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_estimated_dist(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_estimated_dist, 'Type', 'Spearman', 'rows', 'complete');
                    
                    corr_jrd_coviewing(subj, roi) = corr(corr_ROI_jrd_nondiag(:), mat_nondiag_coviewing, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_resp_similarity(subj, roi) = corr(corr_ROI_jrd_nondiag(:), mat_nondiag_resp_similarity, 'Type', 'Spearman', 'rows', 'complete');
                    
                    % Partial correlation
                    partialcorr_jrd_distances(subj, roi) = partialcorr(corr_ROI_jrd_nondiag, mat_nondiag_distance, mat_nondiag_segments, 'Type', 'Spearman', 'rows', 'complete');
                    partialcorr_jrd_distances_cov_resp(subj, roi) = partialcorr(corr_ROI_jrd_nondiag, mat_nondiag_distance, [mat_nondiag_coviewing, mat_nondiag_resp_similarity], 'Type', 'Spearman', 'rows', 'complete');
                    partialcorr_jrd_overlay_cov_resp(subj, roi) = partialcorr(corr_ROI_jrd_nondiag, mat_nondiag_overlay, [mat_nondiag_coviewing, mat_nondiag_resp_similarity], 'Type', 'Spearman', 'rows', 'complete');
                    partialcorr_jrd_flipping_cov_resp(subj, roi) = partialcorr(corr_ROI_jrd_nondiag, mat_nondiag_flipping, [mat_nondiag_coviewing, mat_nondiag_resp_similarity], 'Type', 'Spearman', 'rows', 'complete');
                    partialcorr_jrd_yaxis_cov_resp(subj, roi) = partialcorr(corr_ROI_jrd_nondiag, mat_nondiag_y_axis, [mat_nondiag_coviewing, mat_nondiag_resp_similarity], 'Type', 'Spearman', 'rows', 'complete');
                    partialcorr_jrd_segments(subj, roi) = partialcorr(corr_ROI_jrd_nondiag, mat_nondiag_segments, mat_nondiag_distance, 'Type', 'Spearman', 'rows', 'complete');
                    partialcorr_jrd_orthsegments(subj, roi) = partialcorr(corr_ROI_jrd_nondiag, mat_nondiag_orthsegments, mat_nondiag_distance, 'Type', 'Spearman', 'rows', 'complete');
                    partialcorr_jrd_quadrants(subj, roi) = partialcorr(corr_ROI_jrd_nondiag, mat_nondiag_quadrants, mat_nondiag_distance, 'Type', 'Spearman', 'rows', 'complete');
                    partialcorr_jrd_distances_overlay(subj, roi) = partialcorr(corr_ROI_jrd_nondiag, mat_nondiag_distance, mat_nondiag_overlay, 'Type', 'Spearman', 'rows', 'complete');
                    partialcorr_jrd_overlay_distances(subj, roi) = partialcorr(corr_ROI_jrd_nondiag, mat_nondiag_overlay, mat_nondiag_distance, 'Type', 'Spearman', 'rows', 'complete');
                    
                    % Calculating the segment grouping measure (higher neural similarity within segment compared to between)
                    segment_grouping_jrd(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_segment_grouping, 'Type', 'Spearman', 'rows', 'complete');
                    %                     segment_grouping_newmeasure_jrd(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_segment_grouping_newmeasure, 'Type', 'Spearman', 'rows', 'complete');
                    grouping_newmeasure_factor = nanmean(mat_nondiag_distance(mat_nondiag_segments==1))/nanmean(mat_nondiag_distance(mat_nondiag_segments==0));
                    segment_grouping_newmeasure_jrd(subj, roi) = grouping_newmeasure_factor * nanmean(corr_ROI_jrd_nondiag(mat_nondiag_segments==1)) - nanmean(corr_ROI_jrd_nondiag(mat_nondiag_segments==0));
                    % Calculating the segment remapping measure (higher correlation to distance matrix within segment vs. between segments)
                    segment_remapping_jrd_full(subj, roi) = corr_jrd_dist_within_segment(subj, roi) - corr_jrd_dist_between_segments(subj, roi);
                    segment_remapping_jrd_adjquads(subj, roi) = corr_jrd_dist_within_segment_adj_quad(subj, roi) - corr_jrd_dist_between_segments_adj_quad(subj, roi);
                    
                    % Saving the actual neural correlation
                    all_neural_corr_ROI_jrd_nondiag(:,roi,subj) = corr_ROI_jrd_nondiag;
                    
                    % Neural corr
                    all_neural_corr_ROI_jrd(:,:,roi,subj) = corr_ROI_jrd;
                    
                    % Pattern dist
                    pattern_dist_jrd = 1 - corr_ROI_jrd;
                    allsubjs_pattern_dist_jrd{roi}(:,:,subj) = pattern_dist_jrd;

                end
            end
        end
    end
end


%% Summarizing results

n = length(all_ROIs_individual);

[~, pvals_means_diag_nondiag_objview_halfruns] = ttest(means_diag_minus_nondiag_objview_halfruns,[],'tail','right');
mm1_means_pv_diag_nondiag = [nanmean(means_diag_minus_nondiag_objview_halfruns); pvals_means_diag_nondiag_objview_halfruns];

[~, pvals_segment_grouping_jrd] = ttest(segment_grouping_jrd,[],'tail','right');
[~, pvals_segment_grouping_objview] = ttest(segment_grouping_objview_d2minusd1,[],'tail','right');
mm2_means_pv_segment_grouping_jrd = [nanmean(segment_grouping_jrd); pvals_segment_grouping_jrd];
mm3_means_pv_segment_grouping_objview = [nanmean(segment_grouping_objview_d2minusd1); pvals_segment_grouping_objview];

[~, pvals_segment_remapping_jrd] = ttest(segment_remapping_jrd_full,[],'tail','right');
[~, pvals_segment_remapping_objview] = ttest(segment_remapping_objview_d2minusd1_full,[],'tail','right');
mm4_means_pv_segment_remapping_jrd = [nanmean(segment_remapping_jrd_full); pvals_segment_remapping_jrd];
mm5_means_pv_segment_remapping_objview = [nanmean(segment_remapping_objview_d2minusd1_full); pvals_segment_remapping_objview];



[~, pvals_partialcorr_jrd_distances] = ttest(partialcorr_jrd_distances,[]);
[~, pvals_partialcorr_jrd_segments] = ttest(partialcorr_jrd_segments,[]);
[~, pvals_partialcorr_jrd_quadrants] = ttest(partialcorr_jrd_quadrants,[]);
[~, pvals_partialcorr_jrd_orthsegments] = ttest(partialcorr_jrd_orthsegments,[]);
[~, pvals_partialcorr_objview_d2minusd1_distances] = ttest(partialcorr_objview_d2minusd1_distances,[]);
[~, pvals_partialcorr_objview_d2minusd1_segments] = ttest(partialcorr_objview_d2minusd1_segments,[]);
[~, pvals_partialcorr_objview_d2minusd1_quadrants] = ttest(partialcorr_objview_d2minusd1_quadrants,[]);
[~, pvals_partialcorr_objview_d2minusd1_orthsegments] = ttest(partialcorr_objview_d2minusd1_orthsegments,[]);
pv_partialcorr1_jrd = [pvals_partialcorr_jrd_distances; pvals_partialcorr_jrd_segments; pvals_partialcorr_jrd_quadrants; pvals_partialcorr_jrd_orthsegments];
pv_partialcorr2_objview = [pvals_partialcorr_objview_d2minusd1_distances; pvals_partialcorr_objview_d2minusd1_segments; pvals_partialcorr_objview_d2minusd1_quadrants; pvals_partialcorr_objview_d2minusd1_orthsegments];
mm6_means_partialcorr_jrd = [nanmean(partialcorr_jrd_distances); nanmean(partialcorr_jrd_segments); nanmean(partialcorr_jrd_quadrants); nanmean(partialcorr_jrd_orthsegments)];
mm7_means_partialcorr_objview = [nanmean(partialcorr_objview_d2minusd1_distances); nanmean(partialcorr_objview_d2minusd1_segments); nanmean(partialcorr_objview_d2minusd1_quadrants); nanmean(partialcorr_objview_d2minusd1_orthsegments)];

means1_jrd = [nanmean(corr_jrd_distances);...
    nanmean(corr_jrd_dist_within_quadrant);nanmean(corr_jrd_dist_within_segment_adj_quad);nanmean(corr_jrd_dist_between_segments_adj_quad);nanmean(corr_jrd_dist_diagonal_quadrants);...
    nan(1,n);nanmean(corr_jrd_quadrants_dist);nanmean(corr_jrd_estimated_dist);...
    nan(1,n);nan(1,n);nanmean(corr_jrd_schema);nanmean(corr_jrd_schema_btwn);nanmean(corr_jrd_schema_y_axis_only);...
    nanmean(corr_jrd_flipping);nanmean(corr_jrd_flipping_btwn);nanmean(corr_jrd_flipping_x_axis_only);...
    nanmean(corr_jrd_overlay);nanmean(corr_jrd_overlay_btwn);nanmean(corr_jrd_overlay_x_axis_only);...
    nan(1,n);nan(1,n);nanmean(corr_jrd_segments);nanmean(corr_jrd_quadrants);nanmean(corr_jrd_orth_segments);...
    nan(1,n);nanmean(corr_jrd_y_axis);nanmean(corr_jrd_x_axis);
    nanmean(corr_jrd_y_axis_within_segment);nanmean(corr_jrd_x_axis_within_segment);nanmean(corr_jrd_y_axis_between_segments);nanmean(corr_jrd_x_axis_between_segments);...
    nan(1,n);nanmean(corr_jrd_dist_within_segment);nanmean(corr_jrd_dist_between_segments);
    nan(1,n);nanmean(corr_jrd_schema_btwn_seg_adj_quad);nanmean(corr_jrd_flipping_btwn_seg_adj_quad);nanmean(corr_jrd_overlay_btwn_seg_adj_quad)];
[~,p1] = ttest(corr_jrd_distances,[],'tail','right');
[~,p2] = ttest(corr_jrd_dist_within_quadrant,[],'tail','right');
[~,p3] = ttest(corr_jrd_dist_within_segment_adj_quad,[],'tail','right');
[~,p4] = ttest(corr_jrd_dist_between_segments_adj_quad,[],'tail','right');
[~,p5] = ttest(corr_jrd_dist_diagonal_quadrants,[],'tail','right');
[~,p6] = ttest(corr_jrd_quadrants_dist,[],'tail','right');
[~,p7] = ttest(corr_jrd_estimated_dist,[],'tail','right');
[~,p8] = ttest(corr_jrd_schema,[],'tail','right');
[~,p9] = ttest(corr_jrd_schema_btwn,[],'tail','right');
[~,p9b] = ttest(corr_jrd_schema_y_axis_only,[],'tail','right');
[~,p10] = ttest(corr_jrd_flipping,[],'tail','right');
[~,p11] = ttest(corr_jrd_flipping_btwn,[],'tail','right');
[~,p12] = ttest(corr_jrd_flipping_x_axis_only,[],'tail','right');
[~,p13] = ttest(corr_jrd_overlay,[],'tail','right');
[~,p14] = ttest(corr_jrd_overlay_btwn,[],'tail','right');
[~,p15] = ttest(corr_jrd_overlay_x_axis_only,[],'tail','right');
[~,p16] = ttest(corr_jrd_segments,[],'tail','right');
[~,p17] = ttest(corr_jrd_quadrants,[],'tail','right');
[~,p18] = ttest(corr_jrd_orth_segments,[],'tail','right');
[~,p19] = ttest(corr_jrd_y_axis,[],'tail','right');
[~,p20] = ttest(corr_jrd_x_axis,[],'tail','right');
[~,p21] = ttest(corr_jrd_y_axis_within_segment,[],'tail','right');
[~,p22] = ttest(corr_jrd_x_axis_within_segment,[],'tail','right');
[~,p23] = ttest(corr_jrd_y_axis_between_segments,[],'tail','right');
[~,p24] = ttest(corr_jrd_x_axis_between_segments,[],'tail','right');
[~,p25] = ttest(corr_jrd_dist_within_segment,[],'tail','right');
[~,p26] = ttest(corr_jrd_dist_between_segments,[],'tail','right');
[~,p27] = ttest(corr_jrd_schema_btwn_seg_adj_quad,[],'tail','right');
[~,p28] = ttest(corr_jrd_flipping_btwn_seg_adj_quad,[],'tail','right');
[~,p29] = ttest(corr_jrd_overlay_btwn_seg_adj_quad,[],'tail','right');
pp1_jrd=[p1;p2;p3;p4;p5;nan(1,n);p6;p7;nan(1,n);nan(1,n);p8;p9;p9b;p10;p11;p12;p13;p14;p15;nan(1,n);nan(1,n);p16;p17;p18;nan(1,n);p19;p20;p21;p22;p23;p24;nan(1,n);p25;p26;nan(1,n);p27;p28;p29];

means2_objview_d2minusd1 = [nanmean(corr_objview_d2minusd1_distances);...
    nanmean(corr_objview_d2minusd1_dist_within_quadrant);nanmean(corr_objview_d2minusd1_dist_within_segment_adj_quad);nanmean(corr_objview_d2minusd1_dist_between_segments_adj_quad);nanmean(corr_objview_d2minusd1_dist_diagonal_quadrants);...
    nan(1,n);nanmean(corr_objview_d2minusd1_quadrants_dist);nanmean(corr_objview_d2minusd1_estimated_dist);...
    nan(1,n);nan(1,n);nanmean(corr_objview_d2minusd1_schema);nanmean(corr_objview_d2minusd1_schema_btwn);nanmean(corr_objview_d2minusd1_schema_y_axis_only);...
    nanmean(corr_objview_d2minusd1_flipping);nanmean(corr_objview_d2minusd1_flipping_btwn);nanmean(corr_objview_d2minusd1_flipping_x_axis_only);...
    nanmean(corr_objview_d2minusd1_overlay);nanmean(corr_objview_d2minusd1_overlay_btwn);nanmean(corr_objview_d2minusd1_overlay_x_axis_only);...
    nan(1,n);nan(1,n);nanmean(corr_objview_d2minusd1_segments);nanmean(corr_objview_d2minusd1_quadrants);nanmean(corr_objview_d2minusd1_orth_segments);...
    nan(1,n);nanmean(corr_objview_d2minusd1_y_axis);nanmean(corr_objview_d2minusd1_x_axis);
    nanmean(corr_objview_d2minusd1_y_axis_within_segment);nanmean(corr_objview_d2minusd1_x_axis_within_segment);nanmean(corr_objview_d2minusd1_y_axis_between_segments);nanmean(corr_objview_d2minusd1_x_axis_between_segments);...
    nan(1,n);nanmean(corr_objview_d2minusd1_dist_within_segment);nanmean(corr_objview_d2minusd1_dist_between_segments);
    nan(1,n);nanmean(corr_objview_d2minusd1_schema_btwn_seg_adj_quad);nanmean(corr_objview_d2minusd1_flipping_btwn_seg_adj_quad);nanmean(corr_objview_d2minusd1_overlay_btwn_seg_adj_quad)];
[~,p1] = ttest(corr_objview_d2minusd1_distances,[],'tail','right');
[~,p2] = ttest(corr_objview_d2minusd1_dist_within_quadrant,[],'tail','right');
[~,p3] = ttest(corr_objview_d2minusd1_dist_within_segment_adj_quad,[],'tail','right');
[~,p4] = ttest(corr_objview_d2minusd1_dist_between_segments_adj_quad,[],'tail','right');
[~,p5] = ttest(corr_objview_d2minusd1_dist_diagonal_quadrants,[],'tail','right');
[~,p6] = ttest(corr_objview_d2minusd1_quadrants_dist,[],'tail','right');
[~,p7] = ttest(corr_objview_d2minusd1_estimated_dist,[],'tail','right');
[~,p8] = ttest(corr_objview_d2minusd1_schema,[],'tail','right');
[~,p9] = ttest(corr_objview_d2minusd1_schema_btwn,[],'tail','right');
[~,p9b] = ttest(corr_objview_d2minusd1_schema_y_axis_only,[],'tail','right');
[~,p10] = ttest(corr_objview_d2minusd1_flipping,[],'tail','right');
[~,p11] = ttest(corr_objview_d2minusd1_flipping_btwn,[],'tail','right');
[~,p12] = ttest(corr_objview_d2minusd1_flipping_x_axis_only,[],'tail','right');
[~,p13] = ttest(corr_objview_d2minusd1_overlay,[],'tail','right');
[~,p14] = ttest(corr_objview_d2minusd1_overlay_btwn,[],'tail','right');
[~,p15] = ttest(corr_objview_d2minusd1_overlay_x_axis_only,[],'tail','right');
[~,p16] = ttest(corr_objview_d2minusd1_segments,[],'tail','right');
[~,p17] = ttest(corr_objview_d2minusd1_quadrants,[],'tail','right');
[~,p18] = ttest(corr_objview_d2minusd1_orth_segments,[],'tail','right');
[~,p19] = ttest(corr_objview_d2minusd1_y_axis,[],'tail','right');
[~,p20] = ttest(corr_objview_d2minusd1_x_axis,[],'tail','right');
[~,p21] = ttest(corr_objview_d2minusd1_y_axis_within_segment,[],'tail','right');
[~,p22] = ttest(corr_objview_d2minusd1_x_axis_within_segment,[],'tail','right');
[~,p23] = ttest(corr_objview_d2minusd1_y_axis_between_segments,[],'tail','right');
[~,p24] = ttest(corr_objview_d2minusd1_x_axis_between_segments,[],'tail','right');
[~,p25] = ttest(corr_objview_d2minusd1_dist_within_segment,[],'tail','right');
[~,p26] = ttest(corr_objview_d2minusd1_dist_between_segments,[],'tail','right');
[~,p27] = ttest(corr_objview_d2minusd1_schema_btwn_seg_adj_quad,[],'tail','right');
[~,p28] = ttest(corr_objview_d2minusd1_flipping_btwn_seg_adj_quad,[],'tail','right');
[~,p29] = ttest(corr_objview_d2minusd1_overlay_btwn_seg_adj_quad,[],'tail','right');
pp1_objview_d2minusd1=[p1;p2;p3;p4;p5;nan(1,n);p6;p7;nan(1,n);nan(1,n);p8;p9;p9b;p10;p11;p12;p13;p14;p15;nan(1,n);nan(1,n);p16;p17;p18;nan(1,n);p19;p20;p21;p22;p23;p24;nan(1,n);p25;p26;nan(1,n);p27;p28;p29];
fdr_pp1_objview_d2minusd1 = nan(size(pp1_objview_d2minusd1));       % Calculating FDR-corrected p-values
for i=1:size(fdr_pp1_objview_d2minusd1,1)
    fdr_pp1_objview_d2minusd1(i,1:4) = mafdr(pp1_objview_d2minusd1(i,1:4),'BHFDR','true');
end


means3_objview_day2 = [nanmean(corr_objview_day2_distances);...
    nanmean(corr_objview_day2_dist_within_quadrant);nanmean(corr_objview_day2_dist_within_segment_adj_quad);nanmean(corr_objview_day2_dist_between_segments_adj_quad);nanmean(corr_objview_day2_dist_diagonal_quadrants);...
    nan(1,n);nanmean(corr_objview_day2_quadrants_dist);nanmean(corr_objview_day2_estimated_dist);...
    nan(1,n);nan(1,n);nanmean(corr_objview_day2_schema);nanmean(corr_objview_day2_schema_btwn);nanmean(corr_objview_day2_schema_y_axis_only);...
    nanmean(corr_objview_day2_flipping);nanmean(corr_objview_day2_flipping_btwn);nanmean(corr_objview_day2_flipping_x_axis_only);...
    nanmean(corr_objview_day2_overlay);nanmean(corr_objview_day2_overlay_btwn);nanmean(corr_objview_day2_overlay_x_axis_only);...
    nan(1,n);nan(1,n);nanmean(corr_objview_day2_segments);nanmean(corr_objview_day2_quadrants);nanmean(corr_objview_day2_orth_segments);...
    nan(1,n);nanmean(corr_objview_day2_y_axis);nanmean(corr_objview_day2_x_axis);
    nanmean(corr_objview_day2_y_axis_within_segment);nanmean(corr_objview_day2_x_axis_within_segment);nanmean(corr_objview_day2_y_axis_between_segments);nanmean(corr_objview_day2_x_axis_between_segments);...
    nan(1,n);nanmean(corr_objview_day2_dist_within_segment);nanmean(corr_objview_day2_dist_between_segments);
    nan(1,n);nanmean(corr_objview_day2_schema_btwn_seg_adj_quad);nanmean(corr_objview_day2_flipping_btwn_seg_adj_quad);nanmean(corr_objview_day2_overlay_btwn_seg_adj_quad)];
[~,p1] = ttest(corr_objview_day2_distances,[],'tail','right');
[~,p2] = ttest(corr_objview_day2_dist_within_quadrant,[],'tail','right');
[~,p3] = ttest(corr_objview_day2_dist_within_segment_adj_quad,[],'tail','right');
[~,p4] = ttest(corr_objview_day2_dist_between_segments_adj_quad,[],'tail','right');
[~,p5] = ttest(corr_objview_day2_dist_diagonal_quadrants,[],'tail','right');
[~,p6] = ttest(corr_objview_day2_quadrants_dist,[],'tail','right');
[~,p7] = ttest(corr_objview_day2_estimated_dist,[],'tail','right');
[~,p8] = ttest(corr_objview_day2_schema,[],'tail','right');
[~,p9] = ttest(corr_objview_day2_schema_btwn,[],'tail','right');
[~,p9b] = ttest(corr_objview_day2_schema_y_axis_only,[],'tail','right');
[~,p10] = ttest(corr_objview_day2_flipping,[],'tail','right');
[~,p11] = ttest(corr_objview_day2_flipping_btwn,[],'tail','right');
[~,p12] = ttest(corr_objview_day2_flipping_x_axis_only,[],'tail','right');
[~,p13] = ttest(corr_objview_day2_overlay,[],'tail','right');
[~,p14] = ttest(corr_objview_day2_overlay_btwn,[],'tail','right');
[~,p15] = ttest(corr_objview_day2_overlay_x_axis_only,[],'tail','right');
[~,p16] = ttest(corr_objview_day2_segments,[],'tail','right');
[~,p17] = ttest(corr_objview_day2_quadrants,[],'tail','right');
[~,p18] = ttest(corr_objview_day2_orth_segments,[],'tail','right');
[~,p19] = ttest(corr_objview_day2_y_axis,[],'tail','right');
[~,p20] = ttest(corr_objview_day2_x_axis,[],'tail','right');
[~,p21] = ttest(corr_objview_day2_y_axis_within_segment,[],'tail','right');
[~,p22] = ttest(corr_objview_day2_x_axis_within_segment,[],'tail','right');
[~,p23] = ttest(corr_objview_day2_y_axis_between_segments,[],'tail','right');
[~,p24] = ttest(corr_objview_day2_x_axis_between_segments,[],'tail','right');
[~,p25] = ttest(corr_objview_day2_dist_within_segment,[],'tail','right');
[~,p26] = ttest(corr_objview_day2_dist_between_segments,[],'tail','right');
[~,p27] = ttest(corr_objview_day2_schema_btwn_seg_adj_quad,[],'tail','right');
[~,p28] = ttest(corr_objview_day2_flipping_btwn_seg_adj_quad,[],'tail','right');
[~,p29] = ttest(corr_objview_day2_overlay_btwn_seg_adj_quad,[],'tail','right');
pp1_objview_day2=[p1;p2;p3;p4;p5;nan(1,n);p6;p7;nan(1,n);nan(1,n);p8;p9;p9b;p10;p11;p12;p13;p14;p15;nan(1,n);nan(1,n);p16;p17;p18;nan(1,n);p19;p20;p21;p22;p23;p24;nan(1,n);p25;p26;nan(1,n);p27;p28;p29];





%% MDS

% Summarizing pattern distances
for roi=1:length(all_ROIs_individual)
    allsubjs_mean_pattern_dist_jrd{roi} = nanmean(allsubjs_pattern_dist_jrd{roi},3);
    allsubjs_mean_pattern_dist_objectviewing_day2{roi} = nanmean(allsubjs_pattern_dist_objectviewing_day2{roi},3);
    allsubjs_mean_pattern_dist_objectviewing_day2minus1{roi} = nanmean(allsubjs_pattern_dist_objectviewing_day2minus1{roi},3);
end

% Summarizing neural correlations
neural_corr_jrd_within_quadrant = nan(length(subj_data_dirs), num_ROIs);
neural_corr_jrd_within_segment_adj_quad = nan(length(subj_data_dirs), num_ROIs);
neural_corr_jrd_between_segments_adj_quad = nan(length(subj_data_dirs), num_ROIs);
neural_corr_jrd_diagonal_quadrants = nan(length(subj_data_dirs), num_ROIs);
neural_corr_objviewday2_within_quadrant = nan(length(subj_data_dirs), num_ROIs);
neural_corr_objviewday2_within_segment_adj_quad = nan(length(subj_data_dirs), num_ROIs);
neural_corr_objviewday2_between_segments_adj_quad = nan(length(subj_data_dirs), num_ROIs);
neural_corr_objviewday2_diagonal_quadrants = nan(length(subj_data_dirs), num_ROIs);
neural_corr_objviewd2minusd1_within_quadrant = nan(length(subj_data_dirs), num_ROIs);
neural_corr_objviewd2minusd1_within_segment_adj_quad = nan(length(subj_data_dirs), num_ROIs);
neural_corr_objviewd2minusd1_between_segments_adj_quad = nan(length(subj_data_dirs), num_ROIs);
neural_corr_objviewd2minusd1_diagonal_quadrants = nan(length(subj_data_dirs), num_ROIs);
for subj = 1:length(subj_data_dirs)
    for roi=1:num_ROIs
        curr_neural_corr = all_neural_corr_ROI_jrd(:,:,roi,subj); curr_neural_corr(eye(size(curr_neural_corr)) == 1) = nan;
        neural_corr_jrd_within_quadrant(subj,roi) = nanmean(curr_neural_corr(~isnan(mat_dist_within_quadrant)));
        neural_corr_jrd_within_segment_adj_quad(subj,roi) = nanmean(curr_neural_corr(~isnan(mat_dist_within_segment_adj_quadrants)));
        neural_corr_jrd_between_segments_adj_quad(subj,roi) = nanmean(curr_neural_corr(~isnan(mat_dist_between_segments_adj_quadrants)));
        neural_corr_jrd_diagonal_quadrants(subj,roi) = nanmean(curr_neural_corr(~isnan(mat_dist_diagonal_quadrants)));
        curr_neural_corr = all_neural_corr_objview_day2(:,:,roi,subj); curr_neural_corr(eye(size(curr_neural_corr)) == 1) = nan;
        neural_corr_objviewday2_within_quadrant(subj,roi) = nanmean(curr_neural_corr(~isnan(mat_dist_within_quadrant)));
        neural_corr_objviewday2_within_segment_adj_quad(subj,roi) = nanmean(curr_neural_corr(~isnan(mat_dist_within_segment_adj_quadrants)));
        neural_corr_objviewday2_between_segments_adj_quad(subj,roi) = nanmean(curr_neural_corr(~isnan(mat_dist_between_segments_adj_quadrants)));
        neural_corr_objviewday2_diagonal_quadrants(subj,roi) = nanmean(curr_neural_corr(~isnan(mat_dist_diagonal_quadrants)));
        curr_neural_corr = all_neural_corr_objview_d2minusd1(:,:,roi,subj); curr_neural_corr(eye(size(curr_neural_corr)) == 1) = nan;
        neural_corr_objviewd2minusd1_within_quadrant(subj,roi) = nanmean(curr_neural_corr(~isnan(mat_dist_within_quadrant)));
        neural_corr_objviewd2minusd1_within_segment_adj_quad(subj,roi) = nanmean(curr_neural_corr(~isnan(mat_dist_within_segment_adj_quadrants)));
        neural_corr_objviewd2minusd1_between_segments_adj_quad(subj,roi) = nanmean(curr_neural_corr(~isnan(mat_dist_between_segments_adj_quadrants)));
        neural_corr_objviewd2minusd1_diagonal_quadrants(subj,roi) = nanmean(curr_neural_corr(~isnan(mat_dist_diagonal_quadrants)));
    end
end
m1=[nanmean(neural_corr_jrd_within_quadrant); nanmean(neural_corr_jrd_within_segment_adj_quad);nanmean(neural_corr_jrd_between_segments_adj_quad); nanmean(neural_corr_jrd_diagonal_quadrants)];
m2=[nanmean(neural_corr_objviewd2minusd1_within_quadrant); nanmean(neural_corr_objviewd2minusd1_within_segment_adj_quad);nanmean(neural_corr_objviewd2minusd1_between_segments_adj_quad); nanmean(neural_corr_objviewday2_diagonal_quadrants)];
m3=[nanmean(neural_corr_objviewday2_within_quadrant); nanmean(neural_corr_objviewday2_within_segment_adj_quad);nanmean(neural_corr_objviewday2_between_segments_adj_quad); nanmean(neural_corr_objviewday2_diagonal_quadrants)];



%% MDS
% curr_mat = allsubjs_mean_pattern_dist_jrd;
curr_mat = allsubjs_mean_pattern_dist_objectviewing_day2minus1;
roi = 3;

curr_mat{roi}(find(eye(size(curr_mat{roi})))) = 0;      % Zeroing the diagonal
curr_mat{roi} = curr_mat{roi} - min(curr_mat{roi}(:));     % Normalizing so all values will be positive 
curr_mat{roi}(find(eye(size(curr_mat{roi})))) = 0;      % Zeroing the diagonal
curr_mat{roi} = curr_mat{roi} / max(curr_mat{roi}(:));  % Normalizing to range 0-1

Y = cmdscale(curr_mat{roi},2);      % Multidimensional scaling

% Plotting the MDS, with gradient descent to fit it to actual distance locations as much as possible
nums={}; for i=1:16, nums{i}=num2str(i);end
locations_all_objects = [16 42; 50 58; 57 27; 25 17; ...
    42 -16; 58 -50; 27 -57; 17 -25; ...
    -16 -42; -50 -58; -57 -27; -25 -17; ...
    -42 16; -58 50; -27 57; -17 25];
l1 = locations_all_objects;
l1 = l1/150;
i = -90; R = [cosd(i) -sind(i); sind(i) cosd(i)]; l1 = l1*R; % Rotating to correct environment orientation
% Implementing a numerical gradient descent
param = {[0:360], [-0.02:0.01:0.02], [-0.02:0.01:0.02], [1,1.1], [-1 1]};    % Rotation degree, x-translation, y-translation, scaling, flipping
max_iters = 100;
max_dist_improvement = 0.0001;
curr_dist_improvement = 100;
iter = 1;
while iter <= max_iters && curr_dist_improvement > max_dist_improvement
    % Calculating the current distance
    curr_dist = pdist2(l1, Y);
    curr_dist = sum(diag(curr_dist).^2);    % sum of squared distances
    % Going over parameters to find the best ones
    all_dists = [];
    for deg = 1:length(param{1})     % Degree of rotation
        for xtrans = 1:length(param{2})    % X translation
            for ytrans = 1:length(param{3})  % Y translation
                for sc = 1:length(param{4})    % Scaling
                    for rot = 1:length(param{5})    % Flipping
                        curr_deg = param{1}(deg); curr_xtrans = param{2}(xtrans); curr_ytrans = param{3}(ytrans); curr_sc = param{4}(sc); curr_rot = param{5}(rot);
                        Y_new = Y;
                        Y_new(:,1) = curr_rot * Y_new(:,1);
                        R = [cosd(curr_deg) -sind(curr_deg); sind(curr_deg) cosd(curr_deg)];
                        Y_new = Y_new*R;
                        Y_new(:,1) = Y_new(:,1) + curr_xtrans;
                        Y_new(:,2) = Y_new(:,2) + curr_ytrans;
                        Y_new = Y_new * curr_sc;
                        dist_temp = pdist2(l1, Y_new);
                        all_dists(deg,xtrans,ytrans,sc,rot) = sum(diag(dist_temp).^2);
                    end
                end
            end
        end
    end
    [D,I] = min(all_dists(:));
    [I1,I2,I3,I4,I5] = ind2sub(size(all_dists),I);
    curr_deg = param{1}(I1); curr_xtrans = param{2}(I2); curr_ytrans = param{3}(I3); curr_sc = param{4}(I4); curr_rot = param{5}(I5);
    Y_new = Y;
    Y_new(:,1) = curr_rot * Y_new(:,1);
    R = [cosd(curr_deg) -sind(curr_deg); sind(curr_deg) cosd(curr_deg)];
    Y_new = Y_new*R;
    Y_new(:,1) = Y_new(:,1) + curr_xtrans;
    Y_new(:,2) = Y_new(:,2) + curr_ytrans;
    Y_new = Y_new * curr_sc;
    Y = Y_new;
    curr_dist_improvement = curr_dist - D;
    disp([iter, curr_dist_improvement])
    iter = iter + 1;
end
figure;plot(Y(:,1),Y(:,2),'*'), text(Y(:,1),Y(:,2),nums), % title(['roi ' all_ROI_names{roi}]);
hold on; scatter(l1(:,1),l1(:,2),'r'), text(l1(:,1),l1(:,2),nums,'r')
diffs = Y-l1; quiver(l1(:,1),l1(:,2),diffs(:,1),diffs(:,2),0)
% figure;hold on;plot(Y(1:4,1),Y(1:4,2),'.g',Y(5:8,1),Y(5:8,2),'.b',Y(9:12,1),Y(9:12,2),'.r',Y(13:16,1),Y(13:16,2),'.y','MarkerSize',30), text(Y(:,1),Y(:,2),nums,'FontSize',12), title(['roi ' all_ROI_names{roi}]);
figure;hold on;
scatter(Y(1:2,1),Y(1:2,2),200,'g','p','filled')
scatter(Y(3:4,1),Y(3:4,2),100,'g','s','filled')
scatter(Y([5,8],1),Y([5,8],2),200,'b','p','filled')
scatter(Y([6,7],1),Y([6,7],2),100,'b','s','filled')
scatter(Y([11,12],1),Y([11,12],2),200,'r','p','filled')
scatter(Y([9,10],1),Y([9,10],2),100,'r','s','filled')
scatter(Y([14,15],1),Y([14,15],2),200,'y','p','filled')
scatter(Y([13,16],1),Y([13,16],2),100,'y','s','filled')
text(Y(:,1)+0.01,Y(:,2),nums,'FontSize',12), % title(['roi ' all_ROI_names{roi}])
