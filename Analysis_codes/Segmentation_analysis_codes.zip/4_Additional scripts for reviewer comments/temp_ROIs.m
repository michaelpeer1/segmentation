% Defining ROIs for each subject, based on maximum activation in tasks
data_parent_dir = '/Users/mpeer/Dropbox (Epstein Lab)/Epstein Lab Team Folder/Michael_Peer/1 - Segmentation/Segmentation_data';
subj_data_dirs = dir(fullfile(data_parent_dir, 'sub-seg*'));
num_betas = 16;

betas_file1 = '/Users/mpeer/Dropbox (Epstein Lab)/Epstein Lab Team Folder/Michael_Peer/1 - Segmentation/Segmentation_data/sub-seg01/Analysis/Analysis_objectviewing/Run1/beta_0001.nii';       % Reading one betas file for reslicing of all images to this file's resolution
lRSC = reslice_data('/Users/mpeer/Dropbox/Michael_scripts/templates/func_localizer_parcels_Julian_2012/lRSC.nii', betas_file1, 0);
rRSC = reslice_data('/Users/mpeer/Dropbox/Michael_scripts/templates/func_localizer_parcels_Julian_2012/rRSC.nii', betas_file1, 0);
lPPA = reslice_data('/Users/mpeer/Dropbox/Michael_scripts/templates/func_localizer_parcels_Julian_2012/lPPA.nii', betas_file1, 0);
rPPA = reslice_data('/Users/mpeer/Dropbox/Michael_scripts/templates/func_localizer_parcels_Julian_2012/rPPA.nii', betas_file1, 0);
lOPA = reslice_data('/Users/mpeer/Dropbox/Michael_scripts/templates/func_localizer_parcels_Julian_2012/lTOS.nii', betas_file1, 0);
rOPA = reslice_data('/Users/mpeer/Dropbox/Michael_scripts/templates/func_localizer_parcels_Julian_2012/rTOS.nii', betas_file1, 0);
bilat_RSC = lRSC + rRSC; bilat_PPA = lPPA + rPPA; bilat_OPA = lOPA + rOPA;

all_ROI_names = {'lRSC', 'rRSC', 'lPPA', 'rPPA', 'lOPA', 'rOPA', 'lHC', 'rHC'};
for subj = 1:length(subj_data_dirs)
    disp(subj)
    
    % Defining current subject directories
    curr_subj_analysis_dir = fullfile(fullfile(data_parent_dir, subj_data_dirs(subj).name), 'Analysis');
    curr_subj_localizer_analysis_dir = fullfile(curr_subj_analysis_dir, 'Analysis_localizer');
    curr_subj_objectviewing_analysis_dir = fullfile(curr_subj_analysis_dir, 'Analysis_objectviewing');
    curr_subj_objectviewing_day2_combined_dir = fullfile(curr_subj_objectviewing_analysis_dir, 'Combined_runs_day2');
    curr_subj_jrd_analysis_dir = fullfile(curr_subj_analysis_dir, 'Analysis_JRD');
    curr_subj_jrd_combined_dir = fullfile(curr_subj_jrd_analysis_dir, 'Combined_runs');
    curr_subj_objectviewing_analysis_dirs = {fullfile(curr_subj_objectviewing_analysis_dir, 'Run1'),...
        fullfile(curr_subj_objectviewing_analysis_dir, 'Run2'),...
        fullfile(curr_subj_objectviewing_analysis_dir, 'Run3'),...
        fullfile(curr_subj_objectviewing_analysis_dir, 'Run4')};
    curr_subj_jrd_analysis_dirs = {fullfile(curr_subj_jrd_analysis_dir, 'Run1'),...
        fullfile(curr_subj_jrd_analysis_dir, 'Run2'),...
        fullfile(curr_subj_jrd_analysis_dir, 'Run3')};
    curr_subj_jrd_adaptation_analysis_dir = fullfile(curr_subj_analysis_dir, 'Analysis_JRD_adaptation');
    num_runs_jrd = length(dir(fullfile(curr_subj_jrd_adaptation_analysis_dir, '*confounds.mat')));
    curr_subj_jrd_combined_dir = fullfile(curr_subj_jrd_analysis_dir, 'Combined_runs');
    
    all_ROIs = {lRSC, rRSC, lPPA, rPPA, lOPA, rOPA};
    
    temp_ROIs_jrd = cell(size(all_ROIs));
    % Reading the 100 most active voxels in JRD in each hemisphere and roi, and combining bilaterally
    if exist(fullfile(curr_subj_jrd_combined_dir, 'spmT_0001.nii'),'file')
        all_tvalues_ROI_jrd = nan(length(all_ROIs{1}(:)), num_betas);
        for run = 1:num_runs_jrd
            % Get the already noise-normalized betas (obtained with the temp_noise_normalize_betas script)
            norm_beta_files_current = dir(fullfile(curr_subj_jrd_analysis_dirs{run}, 'normalized_beta*.nii'));
            for b = 1:num_betas
                curr_norm_beta_image = spm_read_vols(spm_vol(fullfile(curr_subj_jrd_analysis_dirs{run}, norm_beta_files_current(b).name)));
                all_tvalues_ROI_jrd(:,b,run) = curr_norm_beta_image(:);
            end
        end
        jrd_contrast = nanmean(nanmean(all_tvalues_ROI_jrd, 2),3);
        jrd_contrast = reshape(jrd_contrast, size(all_ROIs{1}));
        % Defining the ROIs based on the top 100 voxels
        for i=1:length(all_ROIs)
            current_threshold = min(maxk(jrd_contrast(all_ROIs{i} == 1), 100));       % Choosing the 100 voxels with the maximal t value inside the ROI
            temp_ROIs_jrd{i} = all_ROIs{i} & (jrd_contrast >= current_threshold);     % masking the first ROIs with the individual localizer images
        end
    else
        for i=1:length(all_ROIs)
            temp_ROIs_jrd{i} = nan(size(all_ROIs{1}));
        end
    end
    % Reading the 100 most active voxels in object-viewing day2 in each hemisphere and roi, and combining bilaterally
    temp_ROIs_objview = cell(size(all_ROIs));
    if exist(fullfile(curr_subj_objectviewing_day2_combined_dir, 'spmT_0001.nii'),'file')
        % Getting the t-values for all objects and averaging them
        all_tvalues_ROI_objview = nan(length(all_ROIs{1}(:)), num_betas);
        for run = 3:4
            % Get the already noise-normalized betas (obtained with the temp_noise_normalize_betas script)
            norm_beta_files_current = dir(fullfile(curr_subj_objectviewing_analysis_dirs{run}, 'normalized_beta*.nii'));
            for b = 1:num_betas
                curr_norm_beta_image = spm_read_vols(spm_vol(fullfile(curr_subj_objectviewing_analysis_dirs{run}, norm_beta_files_current(b).name)));
                all_tvalues_ROI_objview(:,b,run) = curr_norm_beta_image(:);
            end
        end
        objectviewing_contrast = nanmean(nanmean(all_tvalues_ROI_objview, 2),3);
        objectviewing_contrast = reshape(objectviewing_contrast, size(all_ROIs{1}));
        % Defining the ROIs based on the top 100 voxels
        for i=1:length(all_ROIs)
            current_threshold = min(maxk(objectviewing_contrast(all_ROIs{i} == 1), 100));       % Choosing the 100 voxels with the maximal t value inside the ROI
            temp_ROIs_objview{i} = all_ROIs{i} & (objectviewing_contrast >= current_threshold);     % masking the first ROIs with the individual localizer images
        end
    else
        for i=1:length(all_ROIs)
            temp_ROIs_objview{i} = nan(size(all_ROIs{1}));
        end
    end
   
    all_ROIs_jrd_bilateral{subj} = {temp_ROIs_jrd{1}+temp_ROIs_jrd{2}, temp_ROIs_jrd{3}+temp_ROIs_jrd{4}, temp_ROIs_jrd{5}+temp_ROIs_jrd{6}};
    all_ROIs_objview_bilateral{subj} = {temp_ROIs_objview{1}+temp_ROIs_objview{2}, temp_ROIs_objview{3}+temp_ROIs_objview{4}, temp_ROIs_objview{5}+temp_ROIs_objview{6}};

    % Saving the per-subject ROIs
    all_ROI_names = {'bilat_RSC','bilat_PPA','bilat_OPA'};
    for i = 1:length(all_ROI_names)
        % Saving the per-subject ROI
        save_mat_to_nifti(betas_file1, all_ROIs_jrd_bilateral{subj}{i}, fullfile(curr_subj_localizer_analysis_dir, [all_ROI_names{i}, '_temp_noisenorm_jrd_individual.nii']));
        save_mat_to_nifti(betas_file1, all_ROIs_objview_bilateral{subj}{i}, fullfile(curr_subj_localizer_analysis_dir, [all_ROI_names{i}, '_temp_noisenorm_objview_individual.nii']));
    end
end

for subj=1:length(subj_data_dirs)
    disp(subj);
    curr_subj_analysis_dir = fullfile(fullfile(data_parent_dir, subj_data_dirs(subj).name), 'Analysis');
    curr_subj_localizer_analysis_dir = fullfile(curr_subj_analysis_dir, 'Analysis_localizer');
    rsc = spm_read_vols(spm_vol(fullfile(curr_subj_localizer_analysis_dir, 'bilat_RSC_activation_jrd_individual.nii')));
    ppa = spm_read_vols(spm_vol(fullfile(curr_subj_localizer_analysis_dir, 'bilat_PPA_activation_jrd_individual.nii')));
    opa = spm_read_vols(spm_vol(fullfile(curr_subj_localizer_analysis_dir, 'bilat_OPA_activation_jrd_individual.nii')));
    all_ROIs_jrd_original{subj} = {rsc,ppa,opa};
    rsc = spm_read_vols(spm_vol(fullfile(curr_subj_localizer_analysis_dir, 'bilat_RSC_activation_objview_individual.nii')));
    ppa = spm_read_vols(spm_vol(fullfile(curr_subj_localizer_analysis_dir, 'bilat_PPA_activation_objview_individual.nii')));
    opa = spm_read_vols(spm_vol(fullfile(curr_subj_localizer_analysis_dir, 'bilat_OPA_activation_objview_individual.nii')));
    all_ROIs_objview_original{subj} = {rsc,ppa,opa};
end 

for i=1:24
    for j=1:3
        sums_jrd(i,j) = sum(all_ROIs_jrd_original{i}{j}(:)>0 & all_ROIs_jrd_bilateral{i}{j}(:)>0);
        sums_objview(i,j) = sum(all_ROIs_objview_original{i}{j}(:)>0 & all_ROIs_objview_bilateral{i}{j}(:)>0);
    end
end
sums_jrd(sums_jrd==0)=nan;
