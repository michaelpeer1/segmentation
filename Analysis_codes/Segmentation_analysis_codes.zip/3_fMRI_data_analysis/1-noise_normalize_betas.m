% Perform noise normalization on the data
% The actual noise Normalization uses code from the Decoding Toolbox (TDT - Hebart, Gorgen, Haynes 2015)

betas_file1 = '/Users/mpeer/Dropbox (Epstein Lab)/Epstein Lab Team Folder/Michael_Peer/1 - Segmentation/Segmentation_data/sub-seg01/Analysis/Analysis_objectviewing/Run1/beta_0001.nii';       % Reading one betas file for reslicing of all images to this file's resolution
data_parent_dir = '/Users/mpeer/Dropbox (Epstein Lab)/Epstein Lab Team Folder/Michael_Peer/1 - Segmentation/Segmentation_data';
subj_data_dirs = dir(fullfile(data_parent_dir, 'sub-seg*'));
num_conditions = 16;

%% Go over subjects
for subj = 1:length(subj_data_dirs)
    % Defining current subject directories
    disp(subj)
    % Object viewing analysis dirs
    curr_subj_analysis_dir = fullfile(fullfile(data_parent_dir, subj_data_dirs(subj).name), 'Analysis');
    curr_subj_objectviewing_analysis_dir = fullfile(curr_subj_analysis_dir, 'Analysis_objectviewing');
    curr_subj_objectviewing_analysis_dirs = {fullfile(curr_subj_objectviewing_analysis_dir, 'Run1'),...
        fullfile(curr_subj_objectviewing_analysis_dir, 'Run2'),...
        fullfile(curr_subj_objectviewing_analysis_dir, 'Run3'),...
        fullfile(curr_subj_objectviewing_analysis_dir, 'Run4')};
    num_runs_objectviewing = length(curr_subj_objectviewing_analysis_dirs);
    % JRD analysis dirs
    curr_subj_jrd_analysis_dir = fullfile(curr_subj_analysis_dir, 'Analysis_JRD');
    curr_subj_jrd_analysis_dirs = {fullfile(curr_subj_jrd_analysis_dir, 'Run1'),...
        fullfile(curr_subj_jrd_analysis_dir, 'Run2'),...
        fullfile(curr_subj_jrd_analysis_dir, 'Run3')};
    curr_subj_jrd_adaptation_analysis_dir = fullfile(curr_subj_analysis_dir, 'Analysis_JRD_adaptation');
    num_runs_jrd = length(dir(fullfile(curr_subj_jrd_adaptation_analysis_dir, '*confounds.mat')));
    % Functional localizer analysis dirs
    curr_subj_localizer_analysis_dir = fullfile(curr_subj_analysis_dir, 'Analysis_localizer');
    
    all_analysis_dirs = [curr_subj_objectviewing_analysis_dirs, curr_subj_jrd_analysis_dirs];
    
    % Go over analysis directories
    for d = 1:length(all_analysis_dirs)
        curr_analysis_dir = all_analysis_dirs{d};
        
        % Read SPM file
        if exist(fullfile(curr_analysis_dir, 'SPM.mat'),'file')
            SPM = load(fullfile(curr_analysis_dir, 'SPM.mat'));
            SPM = SPM.SPM;
            
            % Change filenames to correct path
            for f = 1:length(SPM.xY.VY)
                curr_filename = SPM.xY.VY(f).fname;
                loc_start_subj_filename = strfind(curr_filename, 'sub-seg');
                curr_new_filename = [data_parent_dir, curr_filename(loc_start_subj_filename-1:end)];
                SPM.xY.VY(f).fname = curr_new_filename;
                SPM.xY.VY(f).private.dat.fname = curr_new_filename;
            end
            % Change SPM directory to correct path
            curr_filename = SPM.swd;
            loc_start_subj_filename = strfind(curr_filename, 'sub-seg');
            curr_new_filename = [data_parent_dir, curr_filename(loc_start_subj_filename-1:end)];
            SPM.swd = curr_new_filename;
            
            % Use the SPM_write_residuals function to save the GLM residuals
            residuals_filenames = spm_write_residuals(SPM,0);
            num_timepoints = length(residuals_filenames);
            
            % Getting this subject's ROIs and finding all of their coordinates
            all_ROI_names = {'bilat_RSC_activation_jrd', 'bilat_PPA_activation_jrd', 'bilat_OPA_activation_jrd', 'bilat_HC','bilat_RSC_activation_objview', 'bilat_PPA_activation_objview', 'bilat_OPA_activation_objview','bilat_EC'};
            all_ROIs_combined = [];
            for i = 1:length(all_ROI_names)
                all_ROIs_combined = cat(4, all_ROIs_combined, spm_read_vols(spm_vol(fullfile(curr_subj_localizer_analysis_dir, [all_ROI_names{i}, '_individual.nii']))));
            end
            all_ROIs_combined = nanmean(all_ROIs_combined, 4);
            all_ROIs_coords = find(all_ROIs_combined(:) > 0);
            num_ROI_voxels = length(all_ROIs_coords);
            [all_ROI_coordx,all_ROI_coordy,all_ROI_coordz] = ind2sub(size(all_ROIs_combined), all_ROIs_coords);
            
            % Read residuals only from relevant voxels (using individual ROIs combination)
            all_residuals_ROI = nan(num_timepoints, num_ROI_voxels);
            for t = 1:num_timepoints
                all_residuals_ROI(t,:) = spm_sample_vol(spm_vol(fullfile(curr_analysis_dir, residuals_filenames(t).fname)), all_ROI_coordx, all_ROI_coordy, all_ROI_coordz, 0);
            end
            % Read the original betas
            beta_files = dir(fullfile(curr_analysis_dir,'beta*.nii'));
            betas_original = nan(num_conditions, num_ROI_voxels);
            for b = 1:num_conditions
                betas_original(b,:) = spm_sample_vol(spm_vol(fullfile(curr_analysis_dir, beta_files(b).name)), all_ROI_coordx, all_ROI_coordy, all_ROI_coordz, 0);
            end
            
            % Removing voxels with NaN beta values
            locs_notnan = find(~isnan(sum(betas_original)));
            all_residuals_ROI = all_residuals_ROI(:, locs_notnan);
            betas_original = betas_original(:, locs_notnan);
            
            % Compute the covariance matrix and shrink it
            % Get the covariance matrix of the error residuals, with regularization of the matrix through optimal shrikage(Ledoit & Wolf (2004));
            % using the Decoding Toolbox (TDT) function (Hebart, Gorgen, Haynes 2015), since the RSA Toolbox function has a bug (seehttps://github.com/rsagroup/rsatoolbox_matlab/issues/35)
            regularized_covmat = covshrink_lw2(all_residuals_ROI);
            
            % Normalize the betas by the residuals (error) covariance matrix
            [E,D] = eig(regularized_covmat);
            normalized_betas = betas_original*E*diag(1./real(sqrt(diag(D))))*E';
            % Save to a new image
            for b = 1:num_conditions
                new_image = nan(size(all_ROIs_combined));
                new_image(all_ROIs_coords(locs_notnan)) = normalized_betas(b,:);
                numstr_b = num2str(b); if b<10, numstr_b = ['0', numstr_b]; end
                save_mat_to_nifti(betas_file1, new_image, fullfile(curr_analysis_dir, ['normalized_beta', numstr_b, '.nii']));
                clear new_image;
            end
            
            % Delete the residual files from the analysis folder
            for t = 1:num_timepoints
                curr_redisual_filename = fullfile(curr_analysis_dir, residuals_filenames(t).fname);
                delete(curr_redisual_filename);
            end
            % Clear variables
            clear SPM; clear all_ROIs_combined; clear all_residuals_ROI; clear regularized_covmat; clear betas_original; clear normalized_betas; clear E; clear D;
        end
    end
end


