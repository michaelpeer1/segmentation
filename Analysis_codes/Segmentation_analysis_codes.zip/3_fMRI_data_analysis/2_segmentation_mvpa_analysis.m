%% RSA analysis of different model matrices
% New version (May 2021) - using noise normalization, nonparametric statistics

% Defining general variables
betas_file1 = '/Users/mpeer/Dropbox (Epstein Lab)/Epstein Lab Team Folder/Michael_Peer/1 - Segmentation/Segmentation_data/sub-seg01/Analysis/Analysis_objectviewing/Run1/beta_0001.nii';       % Reading one betas file for reslicing of all images to this file's resolution
data_parent_dir = '/Users/mpeer/Dropbox (Epstein Lab)/Epstein Lab Team Folder/Michael_Peer/1 - Segmentation/Segmentation_data';
subj_data_dirs = dir(fullfile(data_parent_dir, 'sub-seg*'));
num_conditions = 16;

% all_ROI_names = {'bilat_RSC_activation_jrd', 'bilat_PPA_activation_jrd', 'bilat_OPA_activation_jrd', 'bilat_HC','bilat_RSC_activation_objview', 'bilat_PPA_activation_objview', 'bilat_OPA_activation_objview','bilat_EC'};
all_ROI_names = {'bilat_RSC_activation_jrd', 'bilat_PPA_activation_jrd', 'bilat_OPA_activation_jrd', 'bilat_HC','bilat_RSC_activation_objview', 'bilat_PPA_activation_objview', 'bilat_OPA_activation_objview','bilat_EC', 'lHCpost','rHCpost','lHCant','rHCant'};
%     all_ROI_names = {'lRSC_activation_jrd', 'rRSC_activation_jrd', 'lPPA_activation_jrd', 'rPPA_activation_jrd', 'lOPA_activation_jrd', 'rOPA_activation_jrd', 'lHC','rHC','lRSC_activation_objview', 'rRSC_activation_objview', 'lPPA_activation_objview', 'rPPA_activation_objview', 'lOPA_activation_objview', 'rOPA_activation_objview','lEC','rEC'};   % Unilateral ROIs
%     all_ROI_names = {'bilat_RSC', 'bilat_PPA', 'bilat_OPA'};      % Localizer ROIs
num_ROIs = length(all_ROI_names);


use_noise_normalization = 1;        % Use multivariate noise normalization of the beta values; otherwise, using the t-values (univariate noise normalization)



%% Creating the different similarity matrices
% Define locations of objects and create the distance matrix
% (in the paper's figures, the same locations that are here 1-16 are 5,6,...,15,16,1,2,3,4)
locations_all_objects = [16 42; 50 58; 57 27; 25 17; ...
    42 -16; 58 -50; 27 -57; 17 -25; ...
    -16 -42; -50 -58; -57 -27; -25 -17; ...
    -42 16; -58 50; -27 57; -17 25];
mat_distances = pdist2(locations_all_objects, locations_all_objects);         % Distances between all objects
mat_distances = mat_distances / max(mat_distances(:));    % Normalizing to range 0-1
% Create the segment identity similarity matrix
mat_segments = ones(num_conditions);
mat_segments(1:4,1:4) = 0; mat_segments(13:16,13:16) = 0; mat_segments(5:12,5:12) = 0; mat_segments(13:16,1:4) = 0; mat_segments(1:4,13:16) = 0;
% Converting all matrices from dissimilarity to similarity matrices
mat_distances = 1 - mat_distances; mat_segments = 1 - mat_segments;


% Schematization matrices

% Overlay (termed "SCHEMATIZATION" in the paper)
locations_new_schematization = locations_all_objects;
locations_new_schematization(5:12,2) = locations_new_schematization(5:12,2) + 75;
mat_schematization = pdist2(locations_new_schematization, locations_new_schematization);         % Distances between all objects
mat_schematization = mat_schematization / max(mat_schematization(:));    % Normalizing to range 0-1
mat_schematization = 1 - mat_schematization;

% Schema preserving (termed "ROTATION" in the paper)
locations_new_rotation = locations_all_objects;
for i = 1:4
    locations_new_rotation(i, :) = locations_new_rotation(i + num_conditions/2, :);
end
for i = 13:16
    locations_new_rotation(i, :) = locations_new_rotation(i - num_conditions/2, :);
end
mat_rotation = pdist2(locations_new_rotation, locations_new_rotation);         % Distances between all objects
mat_rotation = mat_rotation / max(mat_rotation(:));    % Normalizing to range 0-1
mat_rotation = 1 - mat_rotation;



% Flipping (termed "MIRRORING" in the paper)
locations_new_mirroring = locations_all_objects;
locations_new_mirroring(:,2) = abs(locations_new_mirroring(:,2));
mat_mirroring = pdist2(locations_new_mirroring, locations_new_mirroring);         % Distances between all objects
mat_mirroring = mat_mirroring / max(mat_mirroring(:));    % Normalizing to range 0-1
mat_mirroring = 1 - mat_mirroring;


% Organization on Y axis (along river direction - termed "PRINCIPAL AXIS" IN THE PAPER)
mat_principal_axis = pdist2(locations_all_objects(:,1), locations_all_objects(:,1));
mat_principal_axis = mat_principal_axis / max(mat_principal_axis(:));    % Normalizing to range 0-1
mat_principal_axis = 1 - mat_principal_axis;


% Quadrants overlay model (while maintaining the original N/S/E/W directions)
locations_new_quadrants_overlay = locations_all_objects;
locations_new_quadrants_overlay(5:12,2) = locations_new_quadrants_overlay(5:12,2) + 75;
locations_new_quadrants_overlay(9:16,1) = locations_new_quadrants_overlay(9:16,1) + 75;
mat_quadrants_overlay = pdist2(locations_new_quadrants_overlay, locations_new_quadrants_overlay);         % Distances between all objects
mat_quadrants_overlay = mat_quadrants_overlay / max(mat_quadrants_overlay(:));    % Normalizing to range 0-1
mat_quadrants_overlay = 1 - mat_quadrants_overlay;



% Distance within segment only
mat_dist_within_segment = mat_distances;
mat_dist_within_segment(mat_segments==0) = nan;
% Distance between segments only
mat_dist_between_segments = mat_distances;
mat_dist_between_segments(mat_segments==1) = nan;


% Grouping
% A matrix coding if it is an adjacent quadrant within and between segment
mat_within_seg_adj_quad = zeros(num_conditions);
mat_within_seg_adj_quad(1:4,13:16) = 1; mat_within_seg_adj_quad(5:8,9:12) = 1; mat_within_seg_adj_quad(9:12,5:8) = 1; mat_within_seg_adj_quad(13:16,1:4) = 1;
mat_between_seg_adj_quad = zeros(num_conditions);
mat_between_seg_adj_quad(1:4,5:8) = 1; mat_between_seg_adj_quad(5:8,1:4) = 1; mat_between_seg_adj_quad(9:12,13:16) = 1; mat_between_seg_adj_quad(13:16,9:12) = 1;
% A matrix coding a segment grouping index - pattern similarity within segment larger than between segments (adjacent quadrants only)
mat_segment_grouping = nan(num_conditions);
mat_segment_grouping(mat_within_seg_adj_quad == 1) = 1;
mat_segment_grouping(mat_between_seg_adj_quad == 1) = -1;


% Lower triangle elements only
mat_nondiag_distance = mat_distances(find(tril(ones(num_conditions),-1)));
mat_nondiag_segments = mat_segments(find(tril(ones(num_conditions),-1)));
mat_nondiag_rotation = mat_rotation(find(tril(ones(num_conditions),-1)));
mat_nondiag_mirroring = mat_mirroring(find(tril(ones(num_conditions),-1)));
mat_nondiag_schematization = mat_schematization(find(tril(ones(num_conditions),-1)));
mat_nondiag_principal_axis = mat_principal_axis(find(tril(ones(num_conditions),-1)));
mat_nondiag_quadrants_overlay = mat_quadrants_overlay(find(tril(ones(num_conditions),-1)));
mat_nondiag_dist_within_segment = mat_dist_within_segment(find(tril(ones(num_conditions),-1)));
mat_nondiag_dist_between_segments = mat_dist_between_segments(find(tril(ones(num_conditions),-1)));
mat_nondiag_segment_grouping = mat_segment_grouping(find(tril(ones(num_conditions),-1)));




%% RSA in ROIs

% Initialize variables
corr_objview_d2minusd1_distances = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_rotation = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_mirroring = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_schematization = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_principal_axis = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_dist_within_segment = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_dist_between_segments = nan(length(subj_data_dirs), num_ROIs);
corr_objview_d2minusd1_quadrants_overlay = nan(length(subj_data_dirs), num_ROIs);

corr_jrd_distances = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_rotation = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_mirroring = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_schematization = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_principal_axis = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_dist_within_segment = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_dist_between_segments = nan(length(subj_data_dirs), num_ROIs);
corr_jrd_quadrants_overlay = nan(length(subj_data_dirs), num_ROIs);

partialcorr_jrd_distances_cov_resp = nan(length(subj_data_dirs), num_ROIs);
partialcorr_jrd_overlay_cov_resp = nan(length(subj_data_dirs), num_ROIs);
partialcorr_objview_d2minusd1_distances_overlay = nan(length(subj_data_dirs), num_ROIs);
partialcorr_objview_d2minusd1_overlay_distances = nan(length(subj_data_dirs), num_ROIs);
partialcorr_jrd_distances_overlay = nan(length(subj_data_dirs), num_ROIs);
partialcorr_jrd_overlay_distances = nan(length(subj_data_dirs), num_ROIs);

segment_grouping_objview_d2minusd1 = nan(length(subj_data_dirs), num_ROIs);
segment_grouping_newmeasure_objview_d2minusd1 = nan(length(subj_data_dirs), num_ROIs);
segment_remapping_objview_d2minusd1_full = nan(length(subj_data_dirs), num_ROIs);
segment_grouping_jrd = nan(length(subj_data_dirs), num_ROIs);
segment_grouping_newmeasure_jrd = nan(length(subj_data_dirs), num_ROIs);
segment_remapping_jrd_full = nan(length(subj_data_dirs), num_ROIs);


% Calculation RSA in each subject and ROI
for subj = 1:length(subj_data_dirs)
    % Defining current subject directories
    disp(subj)
    % Object viewing analysis dirs
    curr_subj_analysis_dir = fullfile(fullfile(data_parent_dir, subj_data_dirs(subj).name), 'Analysis');
    curr_subj_objectviewing_analysis_dir = fullfile(curr_subj_analysis_dir, 'Analysis_objectviewing');
    curr_subj_objectviewing_analysis_dirs = {fullfile(curr_subj_objectviewing_analysis_dir, 'Run1'),...
        fullfile(curr_subj_objectviewing_analysis_dir, 'Run2'),...
        fullfile(curr_subj_objectviewing_analysis_dir, 'Run3'),...
        fullfile(curr_subj_objectviewing_analysis_dir, 'Run4')};
    num_runs_objectviewing = length(curr_subj_objectviewing_analysis_dirs);
    curr_subj_objectviewing_combined_dirs = {fullfile(curr_subj_objectviewing_analysis_dir, 'Combined_runs_day1'),...
        fullfile(curr_subj_objectviewing_analysis_dir, 'Combined_runs_day2')};
    % JRD analysis dirs
    curr_subj_jrd_analysis_dir = fullfile(curr_subj_analysis_dir, 'Analysis_JRD');
    curr_subj_jrd_analysis_dirs = {fullfile(curr_subj_jrd_analysis_dir, 'Run1'),...
        fullfile(curr_subj_jrd_analysis_dir, 'Run2'),...
        fullfile(curr_subj_jrd_analysis_dir, 'Run3')};
    curr_subj_jrd_adaptation_analysis_dir = fullfile(curr_subj_analysis_dir, 'Analysis_JRD_adaptation');
    num_runs_jrd = length(dir(fullfile(curr_subj_jrd_adaptation_analysis_dir, '*confounds.mat')));
    curr_subj_jrd_combined_dir = fullfile(curr_subj_jrd_analysis_dir, 'Combined_runs');
    % Functional localizer analysis dirs
    curr_subj_localizer_analysis_dir = fullfile(curr_subj_analysis_dir, 'Analysis_localizer');
    
    %% Loading the subject specific ROIs
    all_ROIs_individual = {};
    for i = 1:length(all_ROI_names)
        all_ROIs_individual{i} = spm_read_vols(spm_vol(fullfile(curr_subj_localizer_analysis_dir, [all_ROI_names{i}, '_individual.nii'])));
    end
    
    
    %% MVPA analysis in each ROI
    for roi = 1:num_ROIs        % Going over ROIs
        curr_ROI = find(all_ROIs_individual{roi}(:)==1);
        if ~isempty(curr_ROI)
            % Getting the ROI xyz coordinates
            [curr_ROI_coordx,curr_ROI_coordy,curr_ROI_coordz] = ind2sub(size(all_ROIs_individual{roi}),curr_ROI);
            
            %% Reading the object viewing data
            all_betas_ROI_objview = nan(length(curr_ROI), num_conditions, num_runs_objectviewing);
            for run = 1:num_runs_objectviewing
                if use_noise_normalization == 1
                    % Reading the betas and applying multivariate noise normalization (Walther et al., NeuroImage 2016)
                    % Get the already noise-normalized betas (obtained with the temp_noise_normalize_betas script)
                    norm_beta_files_current = dir(fullfile(curr_subj_objectviewing_analysis_dirs{run}, 'normalized_beta*.nii'));
                    for b = 1:num_conditions
                        curr_norm_beta_image = spm_sample_vol(spm_vol(fullfile(curr_subj_objectviewing_analysis_dirs{run}, norm_beta_files_current(b).name)), curr_ROI_coordx, curr_ROI_coordy, curr_ROI_coordz, 0);
                        all_betas_ROI_objview(:,b,run) = curr_norm_beta_image;
                    end
                else
                    % Get the t-values instead (univariate instead of multivariate noise normalization)
                    t_values_files_current = dir(fullfile(curr_subj_objectviewing_analysis_dirs{run}, 'spmT*.nii'));
                    for b = 1:num_conditions
                        curr_tvalues_image = spm_sample_vol(spm_vol(fullfile(curr_subj_objectviewing_analysis_dirs{run}, t_values_files_current(b).name)), curr_ROI_coordx, curr_ROI_coordy, curr_ROI_coordz, 0);
                        all_betas_ROI_objview(:,b,run) = curr_tvalues_image;
                    end
                end
                
                % Removing the cocktail mean from each day (mean activity at each voxel across patterns)
                mean_run_pattern = nanmean(all_betas_ROI_objview(:,:,run), 2);
                for b = 1:num_conditions
                    all_betas_ROI_objview(:,b,run) = all_betas_ROI_objview(:,b,run) - mean_run_pattern;
                end
            end
            
            % Getting the average pattern across runs, and calculating the correlation between these average patterns
            all_betas_day1 = nanmean(all_betas_ROI_objview(:,:,1:2), 3);
            all_betas_day2 = nanmean(all_betas_ROI_objview(:,:,3:4), 3);
            corr_ROI_objview_day1 = fisherz(corr(all_betas_day1, all_betas_day1, 'rows', 'complete'));
            corr_ROI_objview_day2 = fisherz(corr(all_betas_day2, all_betas_day2, 'rows', 'complete'));
            
            % Non-diagonal elements
            corr_ROI_objview_day1_nondiag = corr_ROI_objview_day1(find(tril(ones(num_conditions),-1)));       % Taking only the lower triangle elements as a vector
            corr_ROI_objview_day2_nondiag = corr_ROI_objview_day2(find(tril(ones(num_conditions),-1)));       % Taking only the lower triangle elements as a vector
            corr_ROI_objview_d2minusd1_nondiag = (corr_ROI_objview_day2_nondiag - corr_ROI_objview_day1_nondiag);            % Day2 minus day1
            
            % Calculating correlation to different matrices
            % Day 2 minus day 1 (change in corrrelation between days)
            corr_objview_d2minusd1_distances(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_distance, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_rotation(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_rotation, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_mirroring(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_mirroring, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_schematization(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_schematization, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_dist_within_segment(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_dist_within_segment, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_dist_between_segments(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_dist_between_segments, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_principal_axis(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_principal_axis, 'Type', 'Spearman', 'rows', 'complete');
            corr_objview_d2minusd1_quadrants_overlay(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_quadrants_overlay, 'Type', 'Spearman', 'rows', 'complete');
            
            % Object viewing runs - partial correlation - day 2 minus day 1 correlations
            partialcorr_objview_d2minusd1_distances_overlay(subj, roi) = partialcorr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_distance, mat_nondiag_schematization, 'Type', 'Spearman', 'rows', 'complete');
            partialcorr_objview_d2minusd1_overlay_distances(subj, roi) = partialcorr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_schematization, mat_nondiag_distance, 'Type', 'Spearman', 'rows', 'complete');
            
            % Calculating the segment grouping measure (higher neural similarity within segment compared to between)
            segment_grouping_objview_d2minusd1(subj, roi) = corr(corr_ROI_objview_d2minusd1_nondiag, mat_nondiag_segment_grouping, 'Type', 'Spearman', 'rows', 'complete');
            grouping_newmeasure_factor = nanmean(mat_nondiag_distance(mat_nondiag_segments==1))/nanmean(mat_nondiag_distance(mat_nondiag_segments==0));
            segment_grouping_newmeasure_objview_d2minusd1(subj, roi) = grouping_newmeasure_factor * nanmean(corr_ROI_objview_d2minusd1_nondiag(mat_nondiag_segments==1)) - nanmean(corr_ROI_objview_d2minusd1_nondiag(mat_nondiag_segments==0));
            % Calculating the segment remapping measure (higher correlation to distance matrix within segment vs. between segments)
            segment_remapping_objview_d2minusd1_full(subj, roi) = corr_objview_d2minusd1_dist_within_segment(subj, roi) - corr_objview_d2minusd1_dist_between_segments(subj, roi);
            
            
            %% JRD data
            if num_runs_jrd > 0
                all_betas_ROI_jrd = nan(length(curr_ROI), num_conditions, num_runs_jrd);
                for run = 1:num_runs_jrd
                    if use_noise_normalization
                        % Reading the betas and applying multivariate noise normalization (Walther et al., NeuroImage 2016)
                        % Get the already noise-normalized betas (obtained with the temp_noise_normalize_betas script)
                        norm_beta_files_current = dir(fullfile(curr_subj_jrd_analysis_dirs{run}, 'normalized_beta*.nii'));
                        for b = 1:num_conditions
                            curr_norm_beta_image = spm_sample_vol(spm_vol(fullfile(curr_subj_jrd_analysis_dirs{run}, norm_beta_files_current(b).name)), curr_ROI_coordx, curr_ROI_coordy, curr_ROI_coordz, 0);
                            all_betas_ROI_jrd(:,b,run) = curr_norm_beta_image;
                        end
                    else
                        % Get the t-values instead (univariate instead of multivariate noise normalization)
                        t_values_files_current = dir(fullfile(curr_subj_jrd_analysis_dirs{run}, 'spmT*.nii'));
                        for b = 1:num_conditions
                            curr_tvalues_image = spm_sample_vol(spm_vol(fullfile(curr_subj_jrd_analysis_dirs{run}, t_values_files_current(b).name)), curr_ROI_coordx, curr_ROI_coordy, curr_ROI_coordz, 0);
                            all_betas_ROI_jrd(:,b,run) = curr_tvalues_image;
                        end
                    end
                    
                    % Removing the cocktail mean from each day (mean activity at each voxel across patterns)
                    mean_run_pattern = nanmean(all_betas_ROI_jrd(:,:,run), 2);
                    for b = 1:num_conditions
                        all_betas_ROI_jrd(:,b,run) = all_betas_ROI_jrd(:,b,run) - mean_run_pattern;
                    end
                end
                
                % Getting the average pattern across runs, and calculating the correlation between these average patterns
                all_betas_jrd = nanmean(all_betas_ROI_jrd, 3);
                corr_ROI_jrd = fisherz(corr(all_betas_jrd, all_betas_jrd, 'rows', 'complete'));
                
                if ~isempty(corr_ROI_jrd)
                    % Getting the non-diagonal elements only of the across-run-combinations-average correlation matrix, averaged across upper and lower triangles
                    corr_ROI_jrd_nondiag = corr_ROI_jrd(find(tril(ones(num_conditions),-1)));
                    
                    % Reading this subject's co-viewing stats and responses similarity stats (created with the behavioral analysis script - analyze_psychopy_all_subjects.m)
                    curr_coviewing_mat_file = fullfile(curr_subj_jrd_analysis_dir, 'object_coviewing_JRD.mat');
                    if exist(curr_coviewing_mat_file, 'file')
                        coviewing_mat = load(fullfile(curr_subj_jrd_analysis_dir, 'object_coviewing_JRD.mat'));
                        coviewing_mat = coviewing_mat.current_subject_coviewing_mat;
                    end
                    curr_resp_similarity_mat_file = fullfile(curr_subj_jrd_analysis_dir, 'responses_similarity_JRD.mat');
                    if exist(curr_resp_similarity_mat_file, 'file')
                        resp_similarity_mat = load(fullfile(curr_subj_jrd_analysis_dir, 'responses_similarity_JRD.mat'));
                        resp_similarity_mat = 1 - resp_similarity_mat.current_responses_diff;       % Converting to similarity instead of dissimilarity
                    end
                    mat_nondiag_coviewing = coviewing_mat(find(tril(ones(num_conditions),-1)));
                    mat_nondiag_resp_similarity = resp_similarity_mat(find(tril(ones(num_conditions),-1)));
                    
                    % Correlations to different matrices
                    corr_jrd_distances(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_distance, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_rotation(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_rotation, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_mirroring(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_mirroring, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_schematization(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_schematization, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_dist_within_segment(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_dist_within_segment, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_dist_between_segments(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_dist_between_segments, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_principal_axis(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_principal_axis, 'Type', 'Spearman', 'rows', 'complete');
                    corr_jrd_quadrants_overlay(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_quadrants_overlay, 'Type', 'Spearman', 'rows', 'complete');
                    
                    % Partial correlations
                    partialcorr_jrd_distances_cov_resp(subj, roi) = partialcorr(corr_ROI_jrd_nondiag, mat_nondiag_distance, [mat_nondiag_coviewing, mat_nondiag_resp_similarity], 'Type', 'Spearman', 'rows', 'complete');
                    partialcorr_jrd_overlay_cov_resp(subj, roi) = partialcorr(corr_ROI_jrd_nondiag, mat_nondiag_schematization, [mat_nondiag_coviewing, mat_nondiag_resp_similarity], 'Type', 'Spearman', 'rows', 'complete');
                    partialcorr_jrd_distances_overlay(subj, roi) = partialcorr(corr_ROI_jrd_nondiag, mat_nondiag_distance, mat_nondiag_schematization, 'Type', 'Spearman', 'rows', 'complete');
                    partialcorr_jrd_overlay_distances(subj, roi) = partialcorr(corr_ROI_jrd_nondiag, mat_nondiag_schematization, mat_nondiag_distance, 'Type', 'Spearman', 'rows', 'complete');
                    
                    % Calculating the segment grouping measure (higher neural similarity within segment compared to between)
                    segment_grouping_jrd(subj, roi) = corr(corr_ROI_jrd_nondiag, mat_nondiag_segment_grouping, 'Type', 'Spearman', 'rows', 'complete');
                    grouping_newmeasure_factor = nanmean(mat_nondiag_distance(mat_nondiag_segments==1))/nanmean(mat_nondiag_distance(mat_nondiag_segments==0));
                    segment_grouping_newmeasure_jrd(subj, roi) = grouping_newmeasure_factor * nanmean(corr_ROI_jrd_nondiag(mat_nondiag_segments==1)) - nanmean(corr_ROI_jrd_nondiag(mat_nondiag_segments==0));
                    % Calculating the segment remapping measure (higher correlation to distance matrix within segment vs. between segments)
                    segment_remapping_jrd_full(subj, roi) = corr_jrd_dist_within_segment(subj, roi) - corr_jrd_dist_between_segments(subj, roi);
                    
                end
            end
        end
    end
end


%% Summarizing results

n = num_ROIs;

% ROIs to use for FDR correction
jrd_ROIs = [1:4,8];
objview_ROIs = [4:8];
HC_ROIs = 9:12;

for i=1:num_ROIs
    pvals_segment_grouping_jrd(i) = signrank(segment_grouping_jrd(:,i),[],'tail','right');
    pvals_segment_grouping_objview(i) = signrank(segment_grouping_objview_d2minusd1(:,i),[],'tail','right');
end
fdr_pvals_segment_grouping_jrd = nan(size(pvals_segment_grouping_jrd)); fdr_pvals_segment_grouping_jrd(jrd_ROIs) = mafdr(pvals_segment_grouping_jrd(jrd_ROIs),'BHFDR','true');
fdr_pvals_segment_grouping_objview = nan(size(pvals_segment_grouping_objview)); fdr_pvals_segment_grouping_objview(objview_ROIs) = mafdr(pvals_segment_grouping_objview(objview_ROIs),'BHFDR','true');

for i=1:num_ROIs
    pvals_segment_remapping_jrd(i) = signrank(segment_remapping_jrd_full(:,i),[],'tail','right');
    pvals_segment_remapping_objview(i) = signrank(segment_remapping_objview_d2minusd1_full(:,i),[],'tail','right');
end
fdr_pvals_segment_remapping_jrd = nan(size(pvals_segment_remapping_jrd)); fdr_pvals_segment_remapping_jrd(jrd_ROIs) = mafdr(pvals_segment_remapping_jrd(jrd_ROIs),'BHFDR','true');
fdr_pvals_segment_remapping_objview = nan(size(pvals_segment_remapping_objview)); fdr_pvals_segment_remapping_objview(objview_ROIs) = mafdr(pvals_segment_remapping_objview(objview_ROIs),'BHFDR','true');


for i=1:num_ROIs
    p1(i) = signrank(corr_jrd_distances(:,i),[],'tail','right');
    p8(i) = signrank(corr_jrd_rotation(:,i),[],'tail','right');
    p10(i) = signrank(corr_jrd_mirroring(:,i),[],'tail','right');
    p13(i) = signrank(corr_jrd_schematization(:,i),[],'tail','right');
    p19(i) = signrank(corr_jrd_principal_axis(:,i),[],'tail','right');
end
pp1_jrd = [p1;p8;p10;p13;p19];
fdr_pp1_jrd = nan(size(pp1_jrd));       % Calculating FDR-corrected p-values
for i=1:size(fdr_pp1_jrd,1)
    fdr_pp1_jrd(i,jrd_ROIs) = mafdr(pp1_jrd(i,jrd_ROIs),'BHFDR','true');
end

for i=1:num_ROIs
    p1(i) = signrank(corr_objview_d2minusd1_distances(:,i),[],'tail','right');
    p8(i) = signrank(corr_objview_d2minusd1_rotation(:,i),[],'tail','right');
    p10(i) = signrank(corr_objview_d2minusd1_mirroring(:,i),[],'tail','right');
    p13(i) = signrank(corr_objview_d2minusd1_schematization(:,i),[],'tail','right');
    p19(i) = signrank(corr_objview_d2minusd1_principal_axis(:,i),[],'tail','right');
end
pp1_objview_d2minusd1 = [p1;p8;p10;p13;p19];
fdr_pp1_objview_d2minusd1 = nan(size(pp1_objview_d2minusd1));       % Calculating FDR-corrected p-values
for i=1:size(fdr_pp1_objview_d2minusd1,1)
    fdr_pp1_objview_d2minusd1(i,objview_ROIs) = mafdr(pp1_objview_d2minusd1(i,objview_ROIs),'BHFDR','true');
end
